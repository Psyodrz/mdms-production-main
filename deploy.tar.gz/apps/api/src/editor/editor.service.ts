import { Injectable, NotFoundException, ForbiddenException, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class EditorService {
  private readonly logger = new Logger(EditorService.name);

  constructor(private readonly prisma: PrismaService) {}

  async getAssignedProjects(userId: string) {
    return this.prisma.project.findMany({
      where: {
        editors: {
          some: { id: userId }
        }
      },
      include: {
        client: { include: { user: { select: { companyName: true, firstName: true, lastName: true } } } },
        renderJobs: { orderBy: { createdAt: 'desc' }, take: 5 }
      },
      orderBy: { shootDate: 'desc' }
    });
  }

  async getProjectDetails(userId: string, projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        editors: true,
        renderJobs: true,
        comments: { orderBy: { createdAt: 'desc' } },
        client: { include: { user: { select: { companyName: true, firstName: true, lastName: true } } } }
      }
    });

    if (!project) throw new NotFoundException('Project not found');

    const isAssigned = project.editors.some((e: any) => e.id === userId);
    if (!isAssigned && userId !== 'SUPER_ADMIN') {
      throw new ForbiddenException('You are not assigned to this project');
    }

    return project;
  }

  async createRenderJob(userId: string, projectId: string, inputFile: string) {
    // Verify assignment
    await this.getProjectDetails(userId, projectId);

    return this.prisma.renderJob.create({
      data: {
        projectId,
        inputFile,
        status: 'QUEUED'
      }
    });
  }

  async updateRenderJobStatus(jobId: string, status: any) {
    const job = await this.prisma.renderJob.update({
      where: { id: jobId },
      data: { status }
    });
    return job;
  }

  async addVersion(userId: string, projectId: string, data: { fileUrl: string, fileName: string, fileSize: number, fileType: string, versionNumber: number }) {
    await this.getProjectDetails(userId, projectId);

    return this.prisma.version.create({
      data: {
        projectId,
        uploadedById: userId,
        fileUrl: data.fileUrl,
        fileName: data.fileName,
        fileSize: BigInt(data.fileSize),
        fileType: data.fileType,
        versionNumber: data.versionNumber,
        status: 'UPLOADED',
        isWatermarked: true,
      }
    });
  }
}
