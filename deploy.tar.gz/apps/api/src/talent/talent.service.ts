import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { TalentProfileStatus } from '@mdms/types';
import { WhatsappService } from '../whatsapp/whatsapp.service';

@Injectable()
export class TalentService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly whatsappService: WhatsappService
  ) {}

  async findAllPublic(query: { search?: string; type?: string; location?: string }) {
    return this.prisma.talentProfile.findMany({
      where: {
        status: TalentProfileStatus.ACTIVE,
        ...(query.type && { talentTypes: { has: query.type as any } }),
        ...(query.search && {
          OR: [
            { bio: { contains: query.search, mode: 'insensitive' } },
            { user: { firstName: { contains: query.search, mode: 'insensitive' } } },
            { user: { lastName: { contains: query.search, mode: 'insensitive' } } },
          ],
        }),
        ...(query.location && { city: { contains: query.location, mode: 'insensitive' } }),
      },
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true,
          },
        },
      },
    });
  }

  async findOnePublic(id: string) {
    const profile = await this.prisma.talentProfile.findUnique({
      where: { id, status: TalentProfileStatus.ACTIVE },
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true,
          },
        },
      },
    });

    if (!profile) {
      throw new NotFoundException('Talent profile not found or inactive');
    }

    return profile;
  }

  async registerTalent(userId: string, data: any) {
    // Upsert talent profile with PENDING_REVIEW status
    return this.prisma.talentProfile.upsert({
      where: { userId },
      update: {
        ...data,
        status: TalentProfileStatus.PENDING_REVIEW,
      },
      create: {
        ...data,
        userId,
        slug: `talent-${Date.now()}`,
        status: TalentProfileStatus.PENDING_REVIEW,
      },
    });
  }

  async getPendingProfiles() {
    return this.prisma.talentProfile.findMany({
      where: { status: TalentProfileStatus.PENDING_REVIEW },
      include: { user: true },
      orderBy: { createdAt: 'desc' }
    });
  }

  async moderateProfile(id: string, status: TalentProfileStatus, reviewNote?: string) {
    const profile = await this.prisma.talentProfile.update({
      where: { id },
      data: { status, reviewNote, approvedAt: status === TalentProfileStatus.ACTIVE ? new Date() : null },
      include: { user: true }
    });

    if (profile.user.phone) {
      if (status === TalentProfileStatus.ACTIVE) {
        this.whatsappService.sendMessage(
          profile.user.phone,
          `Congratulations ${profile.user.firstName}! Your MP Production talent profile has been approved and is now live.`
        );
      } else if (status === TalentProfileStatus.DEACTIVATED || status === TalentProfileStatus.SUSPENDED) {
        this.whatsappService.sendMessage(
          profile.user.phone,
          `MP Production: Your talent profile application update. Note: ${reviewNote || 'Please contact support.'}`
        );
      }
    }

    return profile;
  }
}
