import { Controller, Get, Query, Param, Post, Req, Body, Patch, UseGuards } from '@nestjs/common';
import { TalentService } from './talent.service';
import { Public, Roles } from '../common/decorators/roles.decorator';
import { Role, TalentProfileStatus } from '@mdms/types';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';

@Controller('talent')
@UseGuards(JwtAuthGuard, RolesGuard)
export class TalentController {
  constructor(private readonly talentService: TalentService) {}

  @Public()
  @Get()
  async getPublicDirectory(
    @Query('search') search?: string,
    @Query('type') type?: string,
    @Query('location') location?: string,
  ) {
    const profiles = await this.talentService.findAllPublic({ search, type, location });
    return {
      success: true,
      data: profiles,
    };
  }

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Get('pending')
  async getPendingProfiles() {
    const profiles = await this.talentService.getPendingProfiles();
    return {
      success: true,
      data: profiles,
    };
  }

  @Public()
  @Get(':id')
  async getPublicProfile(@Param('id') id: string) {
    const profile = await this.talentService.findOnePublic(id);
    return {
      success: true,
      data: profile,
    };
  }

  @Roles(Role.TALENT)
  @Post('register')
  async registerProfile(@Req() req: any, @Body() body: any) {
    const profile = await this.talentService.registerTalent(req.user.sub, body);
    return {
      success: true,
      message: 'Talent profile submitted for review successfully.',
      data: profile,
    };
  }

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Patch(':id/moderate')
  async moderateProfile(
    @Param('id') id: string,
    @Body('status') status: TalentProfileStatus,
    @Body('reviewNote') reviewNote?: string
  ) {
    const profile = await this.talentService.moderateProfile(id, status, reviewNote);
    return {
      success: true,
      message: `Profile marked as ${status}`,
      data: profile,
    };
  }
}
