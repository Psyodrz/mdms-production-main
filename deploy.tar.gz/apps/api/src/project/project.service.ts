import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { ProjectStatus } from '@mdms/types';
import { WhatsappService } from '../whatsapp/whatsapp.service';

@Injectable()
export class ProjectService {
  private readonly logger = new Logger(ProjectService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly whatsappService: WhatsappService
  ) {}

  async updateStatus(projectId: string, status: ProjectStatus) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        client: {
          include: { user: true }
        }
      }
    });

    if (!project) throw new NotFoundException('Project not found');

    const updated = await this.prisma.project.update({
      where: { id: projectId },
      data: { status },
    });

    // Send WhatsApp notification
    if (project.client.user.phone) {
      this.whatsappService.sendMessage(
        project.client.user.phone,
        `MP Production: Project ${projectId.slice(0, 8).toUpperCase()} has moved to the ${status.replace('_', ' ')} stage. Track progress on your Client Dashboard.`
      );
    }

    return updated;
  }

  async getProjectDetails(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: {
        client: true,
        bookings: {
          include: {
            talentProfile: true,
          },
        },
      },
    });

    if (!project) throw new NotFoundException('Project not found');
    return project;
  }

  async getPresignedUrl(projectId: string, fileName: string, fileType: string) {
    // TODO: Integrate @aws-sdk/client-s3 and @aws-sdk/s3-request-presigner
    // For now, this acts as the scaffolding for Sprint 1.4 file uploads.
    // Ensure the project exists
    await this.getProjectDetails(projectId);
    
    return {
      url: `https://mock-s3-bucket.s3.amazonaws.com/projects/${projectId}/${fileName}?signature=mock`,
      method: 'PUT',
      fields: {
        'Content-Type': fileType
      }
    };
  }
}
