import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { PaymentStatus, PaymentType } from '@mdms/types';
import * as crypto from 'crypto';

@Injectable()
export class PaymentsService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Generates a mock checkout session
   */
  async createCheckoutSession(projectId: string, amountPaise: number, type: PaymentType) {
    const project = await this.prisma.project.findUnique({ where: { id: projectId } });
    if (!project) throw new NotFoundException('Project not found');

    // Create a pending payment
    const payment = await this.prisma.payment.create({
      data: {
        projectId,
        amount: amountPaise,
        type,
        status: PaymentStatus.PENDING,
        razorpayOrderId: `mock_order_${crypto.randomBytes(8).toString('hex')}`
      }
    });

    return {
      paymentId: payment.id,
      checkoutUrl: `/payment/checkout?order=${payment.razorpayOrderId}`,
      amount: amountPaise,
    };
  }

  /**
   * Mocks the webhook reception of a successful payment
   */
  async simulateSuccessfulPayment(paymentId: string) {
    const payment = await this.prisma.payment.findUnique({ where: { id: paymentId } });
    if (!payment) throw new NotFoundException('Payment not found');

    // Mark payment as completed
    const updatedPayment = await this.prisma.payment.update({
      where: { id: paymentId },
      data: {
        status: PaymentStatus.COMPLETED,
        paidAt: new Date(),
        razorpayPaymentId: `mock_pay_${crypto.randomBytes(8).toString('hex')}`,
      }
    });

    // Automatically generate invoice
    await this.generateInvoice(paymentId);

    return updatedPayment;
  }

  /**
   * Generates an invoice record (and mock PDF)
   */
  private async generateInvoice(paymentId: string) {
    const payment = await this.prisma.payment.findUnique({ where: { id: paymentId } });
    if (!payment) throw new NotFoundException('Payment not found');

    const subtotal = Math.floor(payment.amount / 1.18);
    const gstAmount = payment.amount - subtotal;
    const invoiceNumber = `MPINV-${new Date().getFullYear()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

    return this.prisma.invoice.create({
      data: {
        paymentId,
        invoiceNumber,
        subtotal,
        gstRate: 18,
        gstAmount,
        totalAmount: payment.amount,
        pdfUrl: `https://mock-s3-bucket.s3.amazonaws.com/invoices/${invoiceNumber}.pdf` // Mocked S3 URL
      }
    });
  }

  /**
   * Retrieve all invoices for a client
   */
  async getClientInvoices(userId: string) {
    return this.prisma.invoice.findMany({
      where: {
        payment: {
          project: {
            booking: {
              client: {
                userId
              }
            }
          }
        }
      },
      include: {
        payment: {
          include: {
            project: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
  }
}
