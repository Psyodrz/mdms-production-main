import { Controller, Post, Get, Body, Param, UseGuards, Req } from '@nestjs/common';
import { PaymentsService } from './payments.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles, Public } from '../common/decorators/roles.decorator';
import { Role, PaymentType } from '@mdms/types';

@Controller('payments')
@UseGuards(JwtAuthGuard, RolesGuard)
export class PaymentsController {
  constructor(private readonly paymentsService: PaymentsService) {}

  @Roles(Role.CLIENT, Role.ADMIN, Role.SUPER_ADMIN)
  @Post('checkout/session')
  async createSession(
    @Body('projectId') projectId: string,
    @Body('amount') amount: number,
    @Body('type') type: PaymentType
  ) {
    return this.paymentsService.createCheckoutSession(projectId, amount, type);
  }

  @Roles(Role.CLIENT)
  @Get('invoices')
  async getInvoices(@Req() req: any) {
    return this.paymentsService.getClientInvoices(req.user.id);
  }

  // Admin endpoint to manually mark a payment as successful (simulating webhook)
  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Post('simulate-webhook/:paymentId')
  async simulateWebhook(@Param('paymentId') paymentId: string) {
    return this.paymentsService.simulateSuccessfulPayment(paymentId);
  }
}
