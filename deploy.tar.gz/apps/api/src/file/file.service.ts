import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

/**
 * File Service — S3/R2 operations for media and document storage.
 * Reference: SRS Section 6.3 (File Storage Rules)
 */
@Injectable()
export class FileService {
  private readonly s3: S3Client;
  private readonly bucket: string;

  constructor(private configService: ConfigService) {
    this.bucket = this.configService.get<string>('S3_BUCKET_NAME', 'mdms');
    this.s3 = new S3Client({
      endpoint: this.configService.get<string>('S3_ENDPOINT'),
      region: this.configService.get<string>('S3_REGION', 'auto'),
      credentials: {
        accessKeyId: this.configService.get<string>('S3_ACCESS_KEY', ''),
        secretAccessKey: this.configService.get<string>('S3_SECRET_KEY', ''),
      },
      forcePathStyle: true, // Required for MinIO
    });
  }

  /**
   * Generate a pre-signed upload URL.
   * Client uploads directly to S3 — no data passes through API server.
   */
  async getUploadUrl(params: {
    key: string;
    contentType: string;
    expiresIn?: number;
  }): Promise<{ uploadUrl: string; fileKey: string }> {
    const command = new PutObjectCommand({
      Bucket: this.bucket,
      Key: params.key,
      ContentType: params.contentType,
    });

    const uploadUrl = await getSignedUrl(this.s3, command, {
      expiresIn: params.expiresIn || 3600, // 1 hour
    });

    return { uploadUrl, fileKey: params.key };
  }

  /**
   * Generate a pre-signed download URL.
   * Deliverables: 72-hour expiry per SRS.
   */
  async getDownloadUrl(key: string, expiresIn = 259200): Promise<string> {
    const command = new GetObjectCommand({
      Bucket: this.bucket,
      Key: key,
    });

    return getSignedUrl(this.s3, command, { expiresIn });
  }

  /**
   * Delete a file from S3.
   */
  async deleteFile(key: string): Promise<void> {
    const command = new DeleteObjectCommand({
      Bucket: this.bucket,
      Key: key,
    });
    await this.s3.send(command);
  }

  /**
   * Build client upload path per SRS Section 6.3:
   * s3://mdms/clients/{clientId}/projects/{projectId}/uploads/
   */
  buildClientUploadKey(clientId: string, projectId: string, fileName: string): string {
    return `clients/${clientId}/projects/${projectId}/uploads/${Date.now()}-${fileName}`;
  }

  /**
   * Build deliverable path:
   * s3://mdms/clients/{clientId}/projects/{projectId}/deliverables/
   */
  buildDeliverableKey(clientId: string, projectId: string, fileName: string): string {
    return `clients/${clientId}/projects/${projectId}/deliverables/${Date.now()}-${fileName}`;
  }

  /**
   * Build talent portfolio path.
   */
  buildTalentMediaKey(talentId: string, type: 'photos' | 'videos', fileName: string): string {
    return `talent/${talentId}/${type}/${Date.now()}-${fileName}`;
  }

  /**
   * Build editor version path.
   */
  buildEditorVersionKey(projectId: string, versionNumber: number, fileName: string): string {
    return `projects/${projectId}/versions/v${versionNumber}/${Date.now()}-${fileName}`;
  }
}
