import { Controller, Post, Get, Body, Param, UseGuards, Req } from '@nestjs/common';
import { FileService } from './file.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { Role } from '@mdms/types';

@Controller('files')
@UseGuards(JwtAuthGuard, RolesGuard)
export class FileController {
  constructor(private readonly fileService: FileService) {}

  @Roles(Role.EDITOR, Role.SUPER_ADMIN, Role.ADMIN)
  @Post('editor/upload-url')
  async getEditorUploadUrl(
    @Body('projectId') projectId: string,
    @Body('versionNumber') versionNumber: number,
    @Body('fileName') fileName: string,
    @Body('contentType') contentType: string
  ) {
    const key = this.fileService.buildEditorVersionKey(projectId, versionNumber, fileName);
    return this.fileService.getUploadUrl({ key, contentType });
  }

  @Roles(Role.CLIENT, Role.SUPER_ADMIN, Role.ADMIN)
  @Get('download-url/:key')
  async getDownloadUrl(@Param('key') key: string) {
    const url = await this.fileService.getDownloadUrl(decodeURIComponent(key));
    return { url };
  }
}
