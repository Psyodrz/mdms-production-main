import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { BlogPostStatus } from '@mdms/types';

@Injectable()
export class CmsService {
  constructor(private readonly prisma: PrismaService) {}

  // -- Portfolio --
  async getPortfolioItems(publishedOnly: boolean = false) {
    return this.prisma.portfolioItem.findMany({
      where: publishedOnly ? { isPublished: true } : {},
      orderBy: { sortOrder: 'asc' }
    });
  }

  async getPortfolioItem(slug: string) {
    const item = await this.prisma.portfolioItem.findUnique({ where: { slug } });
    if (!item) throw new NotFoundException('Portfolio item not found');
    return item;
  }

  async upsertPortfolioItem(slug: string, data: any) {
    return this.prisma.portfolioItem.upsert({
      where: { slug },
      update: data,
      create: { slug, ...data }
    });
  }

  async deletePortfolioItem(id: string) {
    return this.prisma.portfolioItem.delete({ where: { id } });
  }

  // -- Blog --
  async getBlogPosts(status?: BlogPostStatus) {
    return this.prisma.blogPost.findMany({
      where: status ? { status } : {},
      orderBy: { createdAt: 'desc' }
    });
  }

  async getBlogPost(slug: string) {
    const post = await this.prisma.blogPost.findUnique({ where: { slug } });
    if (!post) throw new NotFoundException('Blog post not found');
    return post;
  }

  async upsertBlogPost(slug: string, data: any, authorId: string) {
    return this.prisma.blogPost.upsert({
      where: { slug },
      update: data,
      create: { slug, authorId, ...data }
    });
  }

  async deleteBlogPost(id: string) {
    return this.prisma.blogPost.delete({ where: { id } });
  }

  // -- Testimonials --
  async getTestimonials(publishedOnly: boolean = false) {
    return this.prisma.testimonial.findMany({
      where: publishedOnly ? { isPublished: true, isApproved: true } : {},
      orderBy: { sortOrder: 'asc' }
    });
  }

  async createTestimonial(data: any) {
    return this.prisma.testimonial.create({ data });
  }

  async updateTestimonial(id: string, data: any) {
    return this.prisma.testimonial.update({ where: { id }, data });
  }

  async deleteTestimonial(id: string) {
    return this.prisma.testimonial.delete({ where: { id } });
  }

  // -- Team --
  async getTeamMembers(publishedOnly: boolean = false) {
    return this.prisma.teamMember.findMany({
      where: publishedOnly ? { isPublished: true } : {},
      orderBy: { sortOrder: 'asc' }
    });
  }

  async upsertTeamMember(id: string | null, data: any) {
    if (id) {
      return this.prisma.teamMember.update({ where: { id }, data });
    }
    return this.prisma.teamMember.create({ data });
  }

  async deleteTeamMember(id: string) {
    return this.prisma.teamMember.delete({ where: { id } });
  }
}
