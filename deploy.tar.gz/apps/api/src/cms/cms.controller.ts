import { Controller, Get, Post, Patch, Delete, Body, Param, Query, UseGuards, Req } from '@nestjs/common';
import { CmsService } from './cms.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Public, Roles } from '../common/decorators/roles.decorator';
import { Role, BlogPostStatus } from '@mdms/types';

@Controller('cms')
@UseGuards(JwtAuthGuard, RolesGuard)
export class CmsController {
  constructor(private readonly cmsService: CmsService) {}

  // -- Public GETs --
  @Public()
  @Get('portfolio')
  async getPublicPortfolio() {
    return this.cmsService.getPortfolioItems(true);
  }

  @Public()
  @Get('portfolio/:slug')
  async getPublicPortfolioItem(@Param('slug') slug: string) {
    return this.cmsService.getPortfolioItem(slug);
  }

  @Public()
  @Get('blog')
  async getPublicBlog() {
    return this.cmsService.getBlogPosts(BlogPostStatus.PUBLISHED);
  }

  @Public()
  @Get('blog/:slug')
  async getPublicBlogPost(@Param('slug') slug: string) {
    return this.cmsService.getBlogPost(slug);
  }

  @Public()
  @Get('testimonials')
  async getPublicTestimonials() {
    return this.cmsService.getTestimonials(true);
  }

  @Public()
  @Get('team')
  async getPublicTeam() {
    return this.cmsService.getTeamMembers(true);
  }

  // -- Secure Admin Endpoints --

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Get('admin/portfolio')
  async getAdminPortfolio() {
    return this.cmsService.getPortfolioItems(false);
  }

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Post('admin/portfolio')
  async upsertPortfolio(@Body() data: any) {
    return this.cmsService.upsertPortfolioItem(data.slug, data);
  }

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Delete('admin/portfolio/:id')
  async deletePortfolio(@Param('id') id: string) {
    return this.cmsService.deletePortfolioItem(id);
  }

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Get('admin/blog')
  async getAdminBlog() {
    return this.cmsService.getBlogPosts();
  }

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Post('admin/blog')
  async upsertBlog(@Req() req: any, @Body() data: any) {
    return this.cmsService.upsertBlogPost(data.slug, data, req.user.id);
  }

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Delete('admin/blog/:id')
  async deleteBlog(@Param('id') id: string) {
    return this.cmsService.deleteBlogPost(id);
  }

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Get('admin/testimonials')
  async getAdminTestimonials() {
    return this.cmsService.getTestimonials(false);
  }

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Post('admin/testimonials')
  async createTestimonial(@Body() data: any) {
    return this.cmsService.createTestimonial(data);
  }

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Patch('admin/testimonials/:id')
  async updateTestimonial(@Param('id') id: string, @Body() data: any) {
    return this.cmsService.updateTestimonial(id, data);
  }

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Delete('admin/testimonials/:id')
  async deleteTestimonial(@Param('id') id: string) {
    return this.cmsService.deleteTestimonial(id);
  }

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Get('admin/team')
  async getAdminTeam() {
    return this.cmsService.getTeamMembers(false);
  }

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Post('admin/team')
  async upsertTeam(@Body() data: any) {
    return this.cmsService.upsertTeamMember(data.id || null, data);
  }

  @Roles(Role.SUPER_ADMIN, Role.ADMIN)
  @Delete('admin/team/:id')
  async deleteTeam(@Param('id') id: string) {
    return this.cmsService.deleteTeamMember(id);
  }
}
