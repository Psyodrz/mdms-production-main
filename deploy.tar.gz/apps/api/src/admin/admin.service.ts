import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AdminService {
  constructor(private readonly prisma: PrismaService) {}

  async getDashboardKpis() {
    // Total active projects
    const activeProjects = await this.prisma.project.count({
      where: {
        status: {
          notIn: ['COMPLETED', 'DELIVERED']
        }
      }
    });

    // Pending bookings
    const pendingBookings = await this.prisma.booking.count({
      where: {
        status: 'PENDING'
      }
    });

    // Pending talent approvals (where type is UNASSIGNED or some verification flag)
    // Assuming we have an 'isVerified' or 'status' field. Let's use users with role TALENT
    const totalTalent = await this.prisma.user.count({
      where: { role: 'TALENT' }
    });

    return {
      activeProjects,
      pendingBookings,
      totalTalent,
      totalRevenue: '₹4.2M' // Placeholder for actual payment logic
    };
  }

  async getRecentBookings() {
    return this.prisma.booking.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      include: {
        talentProfile: {
          include: { user: true }
        },
        client: true
      }
    });
  }
}
