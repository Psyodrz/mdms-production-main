import { Controller, Get, UseGuards } from '@nestjs/common';
import { AdminService } from './admin.service';
import { Roles } from '../common/decorators/roles.decorator';
import { Role } from '@mdms/types';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';

@Controller('admin')
@UseGuards(JwtAuthGuard, RolesGuard)
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.PROJECT_MANAGER)
  @Get('dashboard/kpis')
  async getDashboardKpis() {
    const data = await this.adminService.getDashboardKpis();
    return { success: true, data };
  }

  @Roles(Role.ADMIN, Role.SUPER_ADMIN, Role.PROJECT_MANAGER)
  @Get('dashboard/recent-bookings')
  async getRecentBookings() {
    const data = await this.adminService.getRecentBookings();
    return { success: true, data };
  }
}
