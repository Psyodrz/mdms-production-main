'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import Link from 'next/link';

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrolled ? 'glass py-4' : 'bg-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-8 flex justify-between items-center">
        {/* Logo */}
        <Link href="/" className="group flex items-center gap-2">
          <div className="w-8 h-8 bg-[var(--color-primary)] rotate-45 group-hover:rotate-90 transition-transform duration-500 ease-out" />
          <span className="font-serif text-2xl tracking-widest text-[var(--color-text-main)]">
            MDMS
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          <Link href="/portfolio" className="text-sm uppercase tracking-widest text-[var(--color-text-muted)] hover:text-[var(--color-primary)] transition-colors">
            Portfolio
          </Link>
          <Link href="/services" className="text-sm uppercase tracking-widest text-[var(--color-text-muted)] hover:text-[var(--color-primary)] transition-colors">
            Services
          </Link>
          <Link href="/talent" className="text-sm uppercase tracking-widest text-[var(--color-text-muted)] hover:text-[var(--color-primary)] transition-colors">
            Talent
          </Link>
          <div className="w-px h-4 bg-[var(--color-border)]" />
          <Link href="/login" className="text-sm uppercase tracking-widest text-[var(--color-text-main)] hover:text-[var(--color-primary)] transition-colors">
            Sign In
          </Link>
        </nav>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-[var(--color-text-main)]"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: '100vh' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden absolute top-full left-0 w-full bg-[var(--color-base)] border-t border-[var(--color-border)] flex flex-col items-center pt-12 gap-8"
          >
            <Link href="/portfolio" className="text-2xl font-serif text-[var(--color-text-muted)] hover:text-[var(--color-primary)] transition-colors">
              Portfolio
            </Link>
            <Link href="/services" className="text-2xl font-serif text-[var(--color-text-muted)] hover:text-[var(--color-primary)] transition-colors">
              Services
            </Link>
            <Link href="/talent" className="text-2xl font-serif text-[var(--color-text-muted)] hover:text-[var(--color-primary)] transition-colors">
              Talent
            </Link>
            <div className="w-12 h-px bg-[var(--color-border)]" />
            <Link href="/login" className="text-xl text-[var(--color-text-main)] hover:text-[var(--color-primary)] transition-colors">
              Sign In
            </Link>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
