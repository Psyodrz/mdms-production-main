'use client';

import { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';
import * as random from 'maath/random/dist/maath-random.esm';
import { motion } from 'framer-motion';

function Starfield(props: any) {
  const ref = useRef<any>(null);
  // Generate 5000 random points in a sphere
  const sphere = useMemo(() => random.inSphere(new Float32Array(5000 * 3), { radius: 1.5 }), []);

  useFrame((state, delta) => {
    if (ref.current) {
      ref.current.rotation.x -= delta / 10;
      ref.current.rotation.y -= delta / 15;
    }
  });

  return (
    <group rotation={[0, 0, Math.PI / 4]}>
      <Points ref={ref} positions={sphere} stride={3} frustumCulled={false} {...props}>
        <PointMaterial
          transparent
          color="#d4af37" // Warm ivory / gold cinematic accent
          size={0.005}
          sizeAttenuation={true}
          depthWrite={false}
        />
      </Points>
    </group>
  );
}

export function Hero() {
  return (
    <section className="relative w-full h-screen flex items-center justify-center overflow-hidden bg-[var(--color-base)]">
      {/* Background WebGL Canvas */}
      <div className="absolute inset-0 z-0 opacity-60">
        <Canvas camera={{ position: [0, 0, 1] }}>
          <Starfield />
        </Canvas>
      </div>

      {/* Cinematic Gradient Overlay */}
      <div className="absolute inset-0 z-10 bg-gradient-to-b from-transparent via-[var(--color-base)]/50 to-[var(--color-base)] pointer-events-none" />

      {/* Hero Content */}
      <div className="relative z-20 flex flex-col items-center text-center px-4 max-w-5xl mx-auto mt-16">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
        >
          <span className="text-[var(--color-primary)] tracking-[0.2em] text-sm uppercase font-semibold mb-4 block">
            The Standard in Production
          </span>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif text-[var(--color-text-main)] leading-tight mb-6">
            Cinematic Mastery.<br />
            <span className="text-[var(--color-text-muted)] italic">Digital Excellence.</span>
          </h1>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="text-lg md:text-xl text-[var(--color-text-muted)] max-w-2xl mb-10 text-balance font-light"
        >
          We unify premium media production and elite talent discovery within a single, seamless digital ecosystem.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.2 }}
          className="flex flex-col sm:flex-row gap-6"
        >
          <a
            href="/portfolio"
            className="px-8 py-4 bg-[var(--color-primary)] text-black font-medium tracking-wide hover:bg-[var(--color-primary-hover)] transition-all duration-300 rounded-sm"
          >
            Explore Portfolio
          </a>
          <a
            href="/talent"
            className="px-8 py-4 glass text-[var(--color-text-main)] font-medium tracking-wide hover:border-[var(--color-primary)] transition-all duration-300 rounded-sm"
          >
            Discover Talent
          </a>
        </motion.div>
      </div>
    </section>
  );
}
