import type { Metadata } from 'next';
import { Inter, Playfair_Display } from 'next/font/google';
import './globals.css';

const inter = Inter({ 
  subsets: ['latin'], 
  variable: '--font-primary',
  display: 'swap',
});

const playfair = Playfair_Display({ 
  subsets: ['latin'], 
  variable: '--font-secondary',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'MP Production | Cinematic Media & Digital Management',
  description: 'Premium cinematic media production and digital management system.',
  openGraph: {
    title: 'MP Production',
    description: 'Premium cinematic media production.',
    url: 'https://mpproduction.com',
    siteName: 'MP Production',
    locale: 'en_US',
    type: 'website',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" data-theme="dark" className={`${inter.variable} ${playfair.variable}`}>
      <body>
        <main className="min-h-screen flex flex-col">
          {children}
        </main>
      </body>
    </html>
  );
}
