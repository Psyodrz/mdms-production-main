import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';

async function getPublicPortfolio() {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    const res = await fetch(`${apiUrl}/cms/portfolio`, { next: { revalidate: 60 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data || [];
  } catch (error) {
    return [];
  }
}

export default async function Portfolio() {
  const items = await getPublicPortfolio();

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <Reveal direction="up">
            <div className="mb-16">
              <span className="text-[var(--color-primary)] tracking-[0.2em] text-sm uppercase font-semibold mb-4 block">
                Our Legacy
              </span>
              <h1 className="text-5xl md:text-7xl font-serif text-[var(--color-text-main)] mb-6">
                Selected Works
              </h1>
              <p className="text-lg text-[var(--color-text-muted)] max-w-2xl text-balance font-light">
                Explore our curated collection of cinematic productions, editorial shoots, and high-impact digital campaigns. Each project represents our commitment to absolute excellence.
              </p>
            </div>
          </Reveal>

          {/* Filters (Dynamic based on data) */}
          <Reveal direction="up" delay={0.2}>
            <div className="flex gap-4 mb-12 overflow-x-auto pb-4 scrollbar-hide">
              {['All', ...Array.from(new Set(items.map((i: any) => i.category || 'Other')))].map((filter: any, i) => (
                <button 
                  key={filter}
                  className={`px-6 py-2 whitespace-nowrap text-sm tracking-wide transition-all duration-300 border ${
                    i === 0 
                      ? 'border-[var(--color-primary)] text-[var(--color-primary)]' 
                      : 'border-[var(--color-border)] text-[var(--color-text-muted)] hover:border-[var(--color-primary-dim)] hover:text-[var(--color-text-main)]'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </Reveal>

          {/* Portfolio Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16">
            {items.length === 0 ? (
              <div className="col-span-full py-20 text-center text-[var(--color-text-muted)]">
                No portfolio items available at this time.
              </div>
            ) : (
              items.map((item: any, idx: number) => (
                <Reveal key={item.id} direction="up" delay={(idx % 3) * 0.1}>
                  <div className="group cursor-pointer">
                    <div className="relative aspect-[4/5] overflow-hidden bg-[var(--color-surface)] mb-6">
                      {/* Hover Overlay */}
                      <div className="absolute inset-0 bg-black/40 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center">
                        <span className="px-6 py-3 border border-[var(--color-primary)] text-[var(--color-primary)] uppercase tracking-widest text-xs translate-y-4 group-hover:translate-y-0 transition-all duration-500">
                          View Project
                        </span>
                      </div>
                      {/* Dynamic Image or Placeholder */}
                      {item.mediaUrl ? (
                        <img src={item.mediaUrl} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 ease-in-out" />
                      ) : (
                        <div className="w-full h-full bg-[var(--color-overlay)] group-hover:scale-105 transition-transform duration-1000 ease-in-out" />
                      )}
                    </div>
                    
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-2xl font-serif text-[var(--color-text-main)] group-hover:text-[var(--color-primary)] transition-colors duration-300">
                          {item.title}
                        </h3>
                        <p className="text-[var(--color-text-muted)] text-sm mt-2 uppercase tracking-wider capitalize">
                          {item.category || 'Project'}
                        </p>
                      </div>
                      <span className="text-[var(--color-text-muted)] text-sm font-light">
                        {new Date(item.createdAt).getFullYear()}
                      </span>
                    </div>
                  </div>
                </Reveal>
              ))
            )}
          </div>
        </div>
      </main>

      <footer className="py-12 px-4 border-t border-[var(--color-border)] bg-[var(--color-base)] text-center">
        <p className="text-[var(--color-text-muted)] text-sm">
          &copy; {new Date().getFullYear()} MP Production. All rights reserved.
        </p>
      </footer>
    </>
  );
}
