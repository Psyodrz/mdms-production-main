import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';

async function getAssignedProjects() {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    // Requires Editor token in production
    const res = await fetch(`${apiUrl}/editor/projects`, { next: { revalidate: 0 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data || [];
  } catch (error) {
    return [];
  }
}

export default async function EditorPortal() {
  const projects = await getAssignedProjects();

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          <Reveal direction="up">
            <div className="mb-12 border-b border-[var(--color-border)] pb-8 flex justify-between items-end">
              <div>
                <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-2 block">
                  Workspace
                </span>
                <h1 className="text-4xl font-serif text-[var(--color-text-main)]">
                  Editor Portal
                </h1>
              </div>
              <div className="flex gap-4">
                <button className="text-[var(--color-text-muted)] hover:text-[var(--color-primary)] uppercase text-sm tracking-widest transition-colors">
                  My Tasks
                </button>
                <button className="text-[var(--color-text-muted)] hover:text-[var(--color-primary)] uppercase text-sm tracking-widest transition-colors">
                  Render Queue
                </button>
              </div>
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.1}>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Active Projects List */}
              <div className="lg:col-span-2 space-y-6">
                <h2 className="text-xl font-serif text-[var(--color-text-main)]">Active Projects</h2>
                
                {projects.length === 0 ? (
                  <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-8 text-center text-[var(--color-text-muted)]">
                    No active projects assigned to you.
                  </div>
                ) : (
                  projects.map((project: any) => (
                    <div key={project.id} className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-xl font-medium text-[var(--color-text-main)]">{project.name}</h3>
                          <p className="text-[var(--color-text-muted)] text-sm mt-1">Client: {project.client?.user?.companyName || 'N/A'}</p>
                        </div>
                        <span className="px-3 py-1 bg-[var(--color-primary)] text-black text-xs uppercase tracking-widest font-semibold">
                          {project.status.replace('_', ' ')}
                        </span>
                      </div>
                      
                      <div className="flex gap-6 border-t border-[var(--color-border)] pt-4 mt-4">
                        <div className="flex-1">
                          <span className="block text-xs uppercase tracking-widest text-[var(--color-text-muted)] mb-1">Edit Deadline</span>
                          <span className="text-sm">{project.editDeadline ? new Date(project.editDeadline).toLocaleDateString() : 'TBD'}</span>
                        </div>
                        <div className="flex-1">
                          <span className="block text-xs uppercase tracking-widest text-[var(--color-text-muted)] mb-1">Internal Notes</span>
                          <span className="text-sm line-clamp-1">{project.internalNotes || 'None'}</span>
                        </div>
                        <div>
                          <a href={`/editor-portal/${project.id}`} className="text-[var(--color-primary)] text-sm uppercase tracking-widest hover:underline mt-4 inline-block">
                            Open Workspace &rarr;
                          </a>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Sidebar Quick Tools */}
              <div className="space-y-6">
                <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6">
                  <h3 className="text-sm uppercase tracking-widest text-[var(--color-text-main)] font-semibold mb-4">Quick Upload</h3>
                  <p className="text-[var(--color-text-muted)] text-xs mb-4">Upload a new proxy or final render directly to S3.</p>
                  <button className="w-full py-3 border border-[var(--color-border)] hover:border-[var(--color-text-main)] text-sm tracking-widest uppercase transition-colors">
                    Select File
                  </button>
                </div>
              </div>

            </div>
          </Reveal>

        </div>
      </main>
    </>
  );
}
