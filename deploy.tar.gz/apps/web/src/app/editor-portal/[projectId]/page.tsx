import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';
import { notFound } from 'next/navigation';

async function getProjectDetails(projectId: string) {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    // Requires Editor token in production
    const res = await fetch(`${apiUrl}/editor/projects/${projectId}`, { next: { revalidate: 0 } });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data;
  } catch (error) {
    return null;
  }
}

export default async function EditorProjectWorkspace({ params }: { params: { projectId: string } }) {
  const project = await getProjectDetails(params.projectId);

  if (!project) {
    // In dev mode, we'll mock it if API fails for UI preview
    if (process.env.NODE_ENV !== 'production') {
      return <MockEditorWorkspace projectId={params.projectId} />;
    }
    return notFound();
  }

  return <WorkspaceUI project={project} />;
}

function WorkspaceUI({ project }: { project: any }) {
  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          <Reveal direction="up">
            <div className="mb-12 border-b border-[var(--color-border)] pb-8 flex justify-between items-end">
              <div>
                <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-2 block">
                  Project Workspace
                </span>
                <h1 className="text-4xl font-serif text-[var(--color-text-main)]">
                  {project.name}
                </h1>
                <p className="text-[var(--color-text-muted)] mt-2">Client: {project.client?.user?.companyName}</p>
              </div>
              <div className="flex gap-4">
                <span className="px-4 py-2 border border-[var(--color-border)] bg-[var(--color-surface)] uppercase tracking-widest text-xs font-semibold">
                  Status: {project.status.replace('_', ' ')}
                </span>
              </div>
            </div>
          </Reveal>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            <div className="lg:col-span-2 space-y-8">
              <Reveal direction="up" delay={0.1}>
                <section>
                  <h2 className="text-xl font-serif text-[var(--color-text-main)] mb-6">Asset Library & Versions</h2>
                  <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-8 text-center border-dashed">
                    <p className="text-[var(--color-text-muted)] mb-4">Drag and drop new video versions here</p>
                    <button className="px-6 py-2 bg-[var(--color-primary)] text-black uppercase tracking-widest text-xs font-semibold hover:bg-white transition-colors">
                      Upload New Version
                    </button>
                    <p className="text-xs text-[var(--color-text-muted)] mt-4 text-left border-t border-[var(--color-border)] pt-4">
                      * Uploads are sent securely via AWS S3 Presigned URLs. Ensure your proxy is heavily compressed (H.264/WebM) before uploading for client review.
                    </p>
                  </div>
                </section>
              </Reveal>

              <Reveal direction="up" delay={0.2}>
                <section>
                  <h2 className="text-xl font-serif text-[var(--color-text-main)] mb-6">Client Feedback</h2>
                  <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6">
                    {project.comments && project.comments.length > 0 ? (
                      <ul className="space-y-4">
                        {project.comments.map((comment: any) => (
                          <li key={comment.id} className="border-b border-[var(--color-border)] pb-4 last:border-0 last:pb-0">
                            <div className="flex justify-between mb-1">
                              <span className="text-[var(--color-primary)] font-mono text-sm">{comment.timestampSec ? `@ ${comment.timestampSec}s` : 'General'}</span>
                              <span className="text-[var(--color-text-muted)] text-xs">{new Date(comment.createdAt).toLocaleDateString()}</span>
                            </div>
                            <p className="text-sm">{comment.content}</p>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-[var(--color-text-muted)] text-sm italic">No client feedback yet.</p>
                    )}
                  </div>
                </section>
              </Reveal>
            </div>

            <div className="space-y-8">
              <Reveal direction="up" delay={0.3}>
                <section>
                  <h2 className="text-xl font-serif text-[var(--color-text-main)] mb-6">Project Brief</h2>
                  <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6 space-y-4">
                    <div>
                      <span className="block text-xs uppercase tracking-widest text-[var(--color-text-muted)] mb-1">Edit Deadline</span>
                      <span className="text-sm">{project.editDeadline ? new Date(project.editDeadline).toLocaleDateString() : 'TBD'}</span>
                    </div>
                    <div>
                      <span className="block text-xs uppercase tracking-widest text-[var(--color-text-muted)] mb-1">Internal Notes</span>
                      <p className="text-sm">{project.internalNotes || 'No notes provided.'}</p>
                    </div>
                    {project.briefPdfUrl && (
                      <a href={project.briefPdfUrl} target="_blank" rel="noreferrer" className="block text-center w-full py-2 border border-[var(--color-text-main)] hover:bg-[var(--color-text-main)] hover:text-black uppercase tracking-widest text-xs transition-colors">
                        Download PDF Brief
                      </a>
                    )}
                  </div>
                </section>
              </Reveal>
            </div>

          </div>
        </div>
      </main>
    </>
  );
}

// Fallback for UI Development
function MockEditorWorkspace({ projectId }: { projectId: string }) {
  return <WorkspaceUI project={{
    id: projectId,
    name: 'Sample Brand Campaign',
    status: 'EDITING',
    client: { user: { companyName: 'Acme Corp' } },
    editDeadline: new Date().toISOString(),
    internalNotes: 'Use the LUTs from the shared drive. Client wants a fast-paced 15s cut.',
    comments: [
      { id: '1', timestampSec: 12.5, content: 'Can we cut to the wide shot here instead?', createdAt: new Date().toISOString() },
      { id: '2', timestampSec: null, content: 'Overall pacing is great, just the ending feels abrupt.', createdAt: new Date().toISOString() }
    ]
  }} />;
}
