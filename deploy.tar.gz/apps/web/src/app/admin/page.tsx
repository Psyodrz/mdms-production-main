import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';

async function getAdminData() {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    
    // In production, we'd extract the session token from cookies and pass it in headers
    const [kpisRes, bookingsRes] = await Promise.all([
      fetch(`${apiUrl}/admin/dashboard/kpis`, { next: { revalidate: 0 } }),
      fetch(`${apiUrl}/admin/dashboard/recent-bookings`, { next: { revalidate: 0 } })
    ]);
    
    const kpis = kpisRes.ok ? (await kpisRes.json()).data : null;
    const recentBookings = bookingsRes.ok ? (await bookingsRes.json()).data : [];

    return { kpis, recentBookings };
  } catch (error) {
    return { kpis: null, recentBookings: [] };
  }
}

export default async function AdminDashboard() {
  const { kpis, recentBookings } = await getAdminData();

  const stats = kpis ? [
    { label: 'Active Projects', value: kpis.activeProjects },
    { label: 'Pending Bookings', value: kpis.pendingBookings },
    { label: 'Total Revenue (MTD)', value: kpis.totalRevenue },
    { label: 'Total Talent', value: kpis.totalTalent }
  ] : [
    { label: 'Active Projects', value: '...' },
    { label: 'Pending Bookings', value: '...' },
    { label: 'Total Revenue (MTD)', value: '...' },
    { label: 'Total Talent', value: '...' }
  ];

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          <Reveal direction="up">
            <div className="mb-12 flex flex-col md:flex-row justify-between items-start md:items-end border-b border-[var(--color-border)] pb-8">
              <div>
                <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-2 block">
                  Internal Operations
                </span>
                <h1 className="text-4xl font-serif text-[var(--color-text-main)]">
                  Super Admin
                </h1>
              </div>
              <div className="mt-4 md:mt-0 flex gap-4 text-sm">
                <button className="text-[var(--color-text-muted)] hover:text-[var(--color-primary)] transition-colors">Users</button>
                <button className="text-[var(--color-text-muted)] hover:text-[var(--color-primary)] transition-colors">Settings</button>
                <button className="text-[var(--color-text-muted)] hover:text-red-500 transition-colors">Sign Out</button>
              </div>
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.1}>
            {/* KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              {stats.map(stat => (
                <div key={stat.label} className="p-6 border border-[var(--color-border)] bg-[var(--color-surface)]">
                  <h3 className="text-[var(--color-text-muted)] text-sm uppercase tracking-widest mb-4 font-semibold">{stat.label}</h3>
                  <p className="text-4xl font-serif text-[var(--color-text-main)]">{stat.value}</p>
                </div>
              ))}
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.2}>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Recent Bookings */}
              <div className="lg:col-span-2 border border-[var(--color-border)] bg-[var(--color-surface)] p-6">
                <h2 className="text-xl font-serif text-[var(--color-text-main)] mb-6">Recent Bookings</h2>
                <div className="space-y-4">
                  {recentBookings.length === 0 ? (
                    <p className="text-[var(--color-text-muted)] text-sm">No recent bookings found.</p>
                  ) : (
                    recentBookings.map((booking: any) => (
                      <div key={booking.id} className="flex justify-between items-center p-4 bg-[var(--color-base)] border border-[var(--color-border)]">
                        <div>
                          <p className="text-[var(--color-text-main)] font-medium">Inquiry from {booking.client?.user?.firstName || 'Unknown Client'}</p>
                          <p className="text-[var(--color-text-muted)] text-sm">Talent: {booking.talentProfile?.user?.firstName || 'N/A'} | Dates: {new Date(booking.startDate).toLocaleDateString()} - {new Date(booking.endDate).toLocaleDateString()}</p>
                        </div>
                        <span className="px-3 py-1 bg-[var(--color-primary)] text-black text-xs uppercase tracking-widest font-semibold">
                          {booking.status}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Pending Approvals */}
              <div className="border border-[var(--color-border)] bg-[var(--color-surface)] p-6">
                <h2 className="text-xl font-serif text-[var(--color-text-main)] mb-6">Action Required</h2>
                <div className="space-y-4">
                  {[1, 2].map(i => (
                    <div key={i} className="flex justify-between items-center p-4 bg-[var(--color-base)] border border-[var(--color-border)]">
                      <div>
                        <p className="text-[var(--color-text-main)] font-medium">New Talent Profile</p>
                        <p className="text-[var(--color-text-muted)] text-xs uppercase tracking-widest mt-1">Pending Review</p>
                      </div>
                      <button className="text-[var(--color-primary)] text-sm hover:underline">View</button>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </Reveal>

        </div>
      </main>
    </>
  );
}
