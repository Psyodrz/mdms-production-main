import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';

async function getAuditLogs() {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    const res = await fetch(`${apiUrl}/audit?limit=20`, { next: { revalidate: 0 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data || [];
  } catch (error) {
    return [];
  }
}

export default async function AuditLogs() {
  const logs = await getAuditLogs();

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          <Reveal direction="up">
            <div className="mb-12 border-b border-[var(--color-border)] pb-8">
              <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-2 block">
                Security
              </span>
              <h1 className="text-4xl font-serif text-[var(--color-text-main)]">
                Audit Trail
              </h1>
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.1}>
            <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6 overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-[var(--color-border)] text-[var(--color-text-muted)] text-sm tracking-widest uppercase">
                    <th className="pb-4 font-semibold">Timestamp</th>
                    <th className="pb-4 font-semibold">Actor</th>
                    <th className="pb-4 font-semibold">Action</th>
                    <th className="pb-4 font-semibold">Resource</th>
                    <th className="pb-4 font-semibold">IP Address</th>
                  </tr>
                </thead>
                <tbody>
                  {logs.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-[var(--color-text-muted)]">
                        No audit logs found.
                      </td>
                    </tr>
                  ) : (
                    logs.map((log: any) => (
                      <tr key={log.id} className="border-b border-[var(--color-border)] last:border-0 hover:bg-[var(--color-base)] transition-colors">
                        <td className="py-4 text-[var(--color-text-main)] whitespace-nowrap text-sm">
                          {new Date(log.createdAt).toLocaleString()}
                        </td>
                        <td className="py-4 text-[var(--color-text-muted)]">
                          {log.actor ? `${log.actor.firstName} ${log.actor.lastName}` : 'System'}
                        </td>
                        <td className="py-4">
                          <span className="px-2 py-1 bg-white/5 text-[var(--color-primary)] text-xs font-mono uppercase">
                            {log.action}
                          </span>
                        </td>
                        <td className="py-4 text-[var(--color-text-muted)]">
                          {log.resource} <span className="text-xs opacity-50">({log.resourceId})</span>
                        </td>
                        <td className="py-4 text-[var(--color-text-muted)] font-mono text-sm">
                          {log.ipAddress || 'Unknown'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </Reveal>
        </div>
      </main>
    </>
  );
}
