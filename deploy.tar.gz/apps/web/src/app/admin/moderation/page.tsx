import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';

async function getPendingProfiles() {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    // Requires Admin token in production
    const res = await fetch(`${apiUrl}/talent/pending`, { next: { revalidate: 0 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data;
  } catch (error) {
    return [];
  }
}

export default async function ContentModeration() {
  const pendingProfiles = await getPendingProfiles();

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          <Reveal direction="up">
            <div className="mb-12 border-b border-[var(--color-border)] pb-8">
              <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-2 block">
                Internal Operations
              </span>
              <h1 className="text-4xl font-serif text-[var(--color-text-main)]">
                Talent Moderation
              </h1>
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.1}>
            <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6">
              <h2 className="text-xl font-serif text-[var(--color-text-main)] mb-6">Pending Approvals ({pendingProfiles.length})</h2>
              
              <div className="space-y-4">
                {pendingProfiles.length === 0 ? (
                  <p className="text-[var(--color-text-muted)]">No profiles currently pending review.</p>
                ) : (
                  pendingProfiles.map((profile: any) => (
                    <div key={profile.id} className="flex flex-col md:flex-row justify-between items-start md:items-center p-4 bg-[var(--color-base)] border border-[var(--color-border)]">
                      <div>
                        <p className="text-[var(--color-text-main)] font-medium text-lg">
                          {profile.user?.firstName} {profile.user?.lastName}
                        </p>
                        <p className="text-[var(--color-text-muted)] text-sm">
                          Types: {profile.talentTypes?.join(', ')} | City: {profile.city}
                        </p>
                        <p className="text-[var(--color-text-muted)] text-sm mt-2 max-w-2xl line-clamp-2">
                          {profile.bio}
                        </p>
                      </div>
                      
                      <div className="mt-4 md:mt-0 flex gap-3">
                        <button className="px-4 py-2 border border-[var(--color-border)] hover:border-[var(--color-text-main)] transition-colors text-sm uppercase tracking-widest font-semibold">
                          View Details
                        </button>
                        <button className="px-4 py-2 bg-[var(--color-primary)] text-black hover:bg-[var(--color-primary-hover)] transition-colors text-sm uppercase tracking-widest font-semibold">
                          Approve
                        </button>
                        <button className="px-4 py-2 bg-red-900/20 text-red-500 hover:bg-red-900/40 transition-colors border border-red-900/50 text-sm uppercase tracking-widest font-semibold">
                          Reject
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </Reveal>
        </div>
      </main>
    </>
  );
}
