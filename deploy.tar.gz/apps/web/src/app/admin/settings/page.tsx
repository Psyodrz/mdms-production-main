import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';

async function getFeatureFlags() {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    const res = await fetch(`${apiUrl}/system/flags`, { next: { revalidate: 0 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data || [];
  } catch (error) {
    return [];
  }
}

export default async function AdminSettings() {
  const flags = await getFeatureFlags();

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          <Reveal direction="up">
            <div className="mb-12 border-b border-[var(--color-border)] pb-8 flex justify-between items-end">
              <div>
                <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-2 block">
                  Configuration
                </span>
                <h1 className="text-4xl font-serif text-[var(--color-text-main)]">
                  System Settings
                </h1>
              </div>
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.1}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              
              {/* Feature Flags */}
              <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6">
                <h2 className="text-xl font-serif text-[var(--color-text-main)] mb-6">Feature Flags</h2>
                
                <div className="space-y-4">
                  {flags.length === 0 ? (
                    <p className="text-[var(--color-text-muted)] text-sm">No feature flags configured.</p>
                  ) : (
                    flags.map((flag: any) => (
                      <div key={flag.key} className="flex justify-between items-center p-4 border border-[var(--color-border)]">
                        <div>
                          <p className="font-medium text-[var(--color-text-main)]">{flag.key}</p>
                          <p className="text-xs text-[var(--color-text-muted)]">{flag.description}</p>
                        </div>
                        <button className={`px-4 py-2 text-xs uppercase tracking-widest font-semibold transition-colors ${flag.enabled ? 'bg-[var(--color-primary)] text-black' : 'bg-transparent border border-[var(--color-border)] text-[var(--color-text-muted)]'}`}>
                          {flag.enabled ? 'Enabled' : 'Disabled'}
                        </button>
                      </div>
                    ))
                  )}
                  
                  <button className="w-full py-3 mt-4 border border-dashed border-[var(--color-border)] hover:border-[var(--color-text-main)] text-sm tracking-widest uppercase transition-colors text-[var(--color-text-muted)]">
                    + Add Feature Flag
                  </button>
                </div>
              </div>

              {/* General Configs */}
              <div className="space-y-8">
                <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6">
                  <h2 className="text-xl font-serif text-[var(--color-text-main)] mb-6">Business Hours</h2>
                  <p className="text-[var(--color-text-muted)] text-sm mb-4">Manage working days and operational hours for the booking engine.</p>
                  <button className="px-4 py-2 border border-[var(--color-border)] hover:border-[var(--color-text-main)] transition-colors text-sm uppercase tracking-widest font-semibold">
                    Edit Schedule
                  </button>
                </div>

                <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6">
                  <h2 className="text-xl font-serif text-[var(--color-text-main)] mb-6">Blocked Dates</h2>
                  <p className="text-[var(--color-text-muted)] text-sm mb-4">Prevent bookings on specific calendar dates (holidays, maintenance).</p>
                  <button className="px-4 py-2 border border-[var(--color-border)] hover:border-[var(--color-text-main)] transition-colors text-sm uppercase tracking-widest font-semibold">
                    Manage Dates
                  </button>
                </div>
              </div>

            </div>
          </Reveal>

        </div>
      </main>
    </>
  );
}
