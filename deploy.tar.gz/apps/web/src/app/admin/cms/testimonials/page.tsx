import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';

async function getTestimonials() {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    const res = await fetch(`${apiUrl}/cms/admin/testimonials`, { next: { revalidate: 0 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data || [];
  } catch (error) {
    return [];
  }
}

export default async function CMSTestimonials() {
  const testimonials = await getTestimonials();

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          <Reveal direction="up">
            <div className="mb-12 border-b border-[var(--color-border)] pb-8 flex justify-between items-end">
              <div>
                <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-2 block">
                  CMS Administration
                </span>
                <h1 className="text-4xl font-serif text-[var(--color-text-main)]">
                  Testimonials
                </h1>
              </div>
              <button className="px-6 py-3 bg-[var(--color-primary)] text-black font-semibold tracking-widest text-sm uppercase hover:bg-[var(--color-primary-hover)] transition-colors">
                + Add Testimonial
              </button>
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.1}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {testimonials.length === 0 ? (
                <div className="col-span-full bg-[var(--color-surface)] border border-[var(--color-border)] p-8 text-center text-[var(--color-text-muted)]">
                  No testimonials found.
                </div>
              ) : (
                testimonials.map((testim: any) => (
                  <div key={testim.id} className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex text-yellow-500">
                          {Array.from({ length: testim.rating || 5 }).map((_, i) => (
                            <span key={i}>★</span>
                          ))}
                        </div>
                        <div className="flex gap-2">
                          {testim.isApproved && (
                            <span className="text-green-500 text-[10px] uppercase tracking-widest font-bold">Approved</span>
                          )}
                          {testim.isPublished && (
                            <span className="text-blue-500 text-[10px] uppercase tracking-widest font-bold">Live</span>
                          )}
                        </div>
                      </div>
                      <p className="text-[var(--color-text-main)] italic mb-6">"{testim.content}"</p>
                    </div>
                    <div className="border-t border-[var(--color-border)] pt-4 mt-4 flex justify-between items-end">
                      <div>
                        <p className="font-semibold text-sm text-[var(--color-text-main)] uppercase tracking-widest">{testim.clientName}</p>
                        <p className="text-xs text-[var(--color-text-muted)] mt-1">{testim.clientTitle}{testim.clientCompany ? `, ${testim.clientCompany}` : ''}</p>
                      </div>
                      <button className="text-[var(--color-primary)] text-xs uppercase tracking-widest hover:underline">
                        Edit
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </Reveal>
        </div>
      </main>
    </>
  );
}
