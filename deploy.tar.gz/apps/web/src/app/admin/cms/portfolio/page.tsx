import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';

async function getPortfolioItems() {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    // Use the admin endpoint to get drafted items too
    const res = await fetch(`${apiUrl}/cms/admin/portfolio`, { next: { revalidate: 0 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data || [];
  } catch (error) {
    return [];
  }
}

export default async function CMSPortfolio() {
  const items = await getPortfolioItems();

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          <Reveal direction="up">
            <div className="mb-12 border-b border-[var(--color-border)] pb-8 flex justify-between items-end">
              <div>
                <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-2 block">
                  CMS Administration
                </span>
                <h1 className="text-4xl font-serif text-[var(--color-text-main)]">
                  Portfolio Gallery
                </h1>
              </div>
              <button className="px-6 py-3 bg-[var(--color-primary)] text-black font-semibold tracking-widest text-sm uppercase hover:bg-[var(--color-primary-hover)] transition-colors">
                + Add Project
              </button>
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.1}>
            <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6 overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-[var(--color-border)] text-[var(--color-text-muted)] text-sm tracking-widest uppercase">
                    <th className="pb-4 font-semibold">Title</th>
                    <th className="pb-4 font-semibold">Category</th>
                    <th className="pb-4 font-semibold">Media Type</th>
                    <th className="pb-4 font-semibold">Status</th>
                    <th className="pb-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {items.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-[var(--color-text-muted)]">
                        No portfolio items found.
                      </td>
                    </tr>
                  ) : (
                    items.map((item: any) => (
                      <tr key={item.id} className="border-b border-[var(--color-border)] last:border-0 hover:bg-[var(--color-base)] transition-colors">
                        <td className="py-4 font-medium text-[var(--color-text-main)]">
                          {item.title}
                          <span className="block text-xs text-[var(--color-text-muted)] font-normal font-mono">/{item.slug}</span>
                        </td>
                        <td className="py-4 text-[var(--color-text-muted)] capitalize">{item.category}</td>
                        <td className="py-4 text-[var(--color-text-muted)] capitalize">{item.mediaType}</td>
                        <td className="py-4">
                          {item.isPublished ? (
                            <span className="text-green-500 text-sm font-medium uppercase tracking-widest text-xs">Live</span>
                          ) : (
                            <span className="text-yellow-500 text-sm font-medium uppercase tracking-widest text-xs">Draft</span>
                          )}
                        </td>
                        <td className="py-4 text-right">
                          <button className="text-[var(--color-text-muted)] hover:text-[var(--color-primary)] text-sm uppercase tracking-widest transition-colors mr-4">
                            Edit
                          </button>
                          <button className="text-red-500 hover:text-red-400 text-sm uppercase tracking-widest transition-colors">
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </Reveal>
        </div>
      </main>
    </>
  );
}
