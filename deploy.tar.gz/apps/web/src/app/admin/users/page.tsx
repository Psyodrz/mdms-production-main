import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';

async function getUsers() {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    const res = await fetch(`${apiUrl}/users?limit=50`, { next: { revalidate: 0 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data || [];
  } catch (error) {
    return [];
  }
}

export default async function UserDirectory() {
  const users = await getUsers();

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          <Reveal direction="up">
            <div className="mb-12 border-b border-[var(--color-border)] pb-8 flex justify-between items-end">
              <div>
                <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-2 block">
                  Access Management
                </span>
                <h1 className="text-4xl font-serif text-[var(--color-text-main)]">
                  User Directory
                </h1>
              </div>
              <button className="px-6 py-3 border border-[var(--color-border)] hover:border-[var(--color-text-main)] text-sm uppercase tracking-widest font-semibold transition-colors">
                Invite User
              </button>
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.1}>
            <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6 overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-[var(--color-border)] text-[var(--color-text-muted)] text-sm tracking-widest uppercase">
                    <th className="pb-4 font-semibold">Name</th>
                    <th className="pb-4 font-semibold">Email</th>
                    <th className="pb-4 font-semibold">Role</th>
                    <th className="pb-4 font-semibold">Status</th>
                    <th className="pb-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-[var(--color-text-muted)]">
                        No users found.
                      </td>
                    </tr>
                  ) : (
                    users.map((user: any) => (
                      <tr key={user.id} className="border-b border-[var(--color-border)] last:border-0 hover:bg-[var(--color-base)] transition-colors">
                        <td className="py-4 font-medium text-[var(--color-text-main)]">
                          {user.firstName} {user.lastName}
                        </td>
                        <td className="py-4 text-[var(--color-text-muted)]">
                          {user.email}
                        </td>
                        <td className="py-4">
                          <span className="px-2 py-1 bg-[var(--color-primary)] text-black text-xs font-semibold uppercase tracking-widest">
                            {user.role}
                          </span>
                        </td>
                        <td className="py-4">
                          {user.isActive ? (
                            <span className="text-green-500 text-sm font-medium">Active</span>
                          ) : (
                            <span className="text-red-500 text-sm font-medium">Deactivated</span>
                          )}
                        </td>
                        <td className="py-4 text-right">
                          <button className="text-[var(--color-text-muted)] hover:text-[var(--color-primary)] text-sm uppercase tracking-widest transition-colors">
                            Edit Role
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </Reveal>
        </div>
      </main>
    </>
  );
}
