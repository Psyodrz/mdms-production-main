import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';

async function getEmployees() {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    // Requires Admin token in production
    const res = await fetch(`${apiUrl}/employee`, { next: { revalidate: 0 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data || [];
  } catch (error) {
    return [];
  }
}

export default async function EmployeeRoster() {
  const employees = await getEmployees();

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          <Reveal direction="up">
            <div className="mb-12 border-b border-[var(--color-border)] pb-8 flex justify-between items-end">
              <div>
                <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-2 block">
                  Internal Operations
                </span>
                <h1 className="text-4xl font-serif text-[var(--color-text-main)]">
                  Employee Roster
                </h1>
              </div>
              <button className="px-6 py-3 bg-[var(--color-primary)] text-black font-semibold tracking-widest text-sm uppercase hover:bg-[var(--color-primary-hover)] transition-colors">
                + Add Employee
              </button>
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.1}>
            <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6">
              
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-[var(--color-border)] text-[var(--color-text-muted)] text-sm tracking-widest uppercase">
                      <th className="pb-4 font-semibold">Name</th>
                      <th className="pb-4 font-semibold">Designation</th>
                      <th className="pb-4 font-semibold">Department</th>
                      <th className="pb-4 font-semibold">Joined Date</th>
                      <th className="pb-4 font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {employees.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-8 text-center text-[var(--color-text-muted)]">
                          No employees found.
                        </td>
                      </tr>
                    ) : (
                      employees.map((emp: any) => (
                        <tr key={emp.id} className="border-b border-[var(--color-border)] last:border-0 hover:bg-[var(--color-base)] transition-colors">
                          <td className="py-4 font-medium text-[var(--color-text-main)]">
                            {emp.user?.firstName} {emp.user?.lastName}
                            <span className="block text-xs text-[var(--color-text-muted)] font-normal">{emp.user?.email}</span>
                          </td>
                          <td className="py-4 text-[var(--color-text-muted)]">{emp.designation || '-'}</td>
                          <td className="py-4 text-[var(--color-text-muted)]">{emp.department || '-'}</td>
                          <td className="py-4 text-[var(--color-text-muted)]">
                            {emp.joiningDate ? new Date(emp.joiningDate).toLocaleDateString() : '-'}
                          </td>
                          <td className="py-4 text-right">
                            <button className="text-[var(--color-primary)] text-sm uppercase tracking-widest hover:underline">
                              Manage
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

            </div>
          </Reveal>
        </div>
      </main>
    </>
  );
}
