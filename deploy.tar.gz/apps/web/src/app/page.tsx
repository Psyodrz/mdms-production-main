import { Hero } from '@/components/ui/Hero';
import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';

export default function Home() {
  return (
    <>
      <Navbar />
      <Hero />
      
      {/* Featured Portfolio Section */}
      <section className="py-24 px-4 bg-[var(--color-base)] relative z-10 border-t border-[var(--color-border)]">
        <div className="max-w-7xl mx-auto">
          <Reveal direction="up">
            <div className="flex justify-between items-end mb-16">
              <div>
                <span className="text-[var(--color-primary)] tracking-widest text-sm uppercase mb-2 block">
                  Selected Works
                </span>
                <h2 className="text-4xl md:text-5xl font-serif text-[var(--color-text-main)]">
                  Featured Portfolio
                </h2>
              </div>
              <a href="/portfolio" className="hidden md:inline-flex items-center gap-2 text-[var(--color-text-muted)] hover:text-[var(--color-primary)] transition-colors duration-300">
                View All Works
                <span className="text-xl">→</span>
              </a>
            </div>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Dummy Portfolio Items */}
            {[1, 2, 3, 4].map((item, index) => (
              <Reveal key={item} direction="up" delay={index * 0.1}>
                <div className="group cursor-pointer">
                  <div className="relative aspect-video overflow-hidden rounded-sm bg-[var(--color-surface)] mb-4">
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    {/* Placeholder for actual image/video */}
                    <div className="w-full h-full bg-[var(--color-overlay)] group-hover:scale-105 transition-transform duration-700 ease-in-out" />
                  </div>
                  <h3 className="text-xl font-serif text-[var(--color-text-main)] group-hover:text-[var(--color-primary)] transition-colors duration-300">
                    Cinematic Commercial {item}
                  </h3>
                  <p className="text-[var(--color-text-muted)] text-sm mt-1">Brand Campaign</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t border-[var(--color-border)] bg-[var(--color-base)] text-center">
        <p className="text-[var(--color-text-muted)] text-sm">
          &copy; {new Date().getFullYear()} MP Production. All rights reserved.
        </p>
      </footer>
    </>
  );
}
