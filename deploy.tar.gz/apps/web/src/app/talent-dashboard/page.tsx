import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';

async function getTalentProfile() {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    const res = await fetch(`${apiUrl}/talent/me`, { next: { revalidate: 0 } });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data;
  } catch (error) {
    return null;
  }
}

export default async function TalentDashboard() {
  const profile = await getTalentProfile();

  // Mocking profile for UI dev if not found
  const mockProfile = profile || {
    id: 'mock_123',
    slug: 'aria-v',
    status: 'ACTIVE',
    bio: 'Professional model and actress based in Mumbai.',
    city: 'Mumbai',
    availability: 'FLEXIBLE',
    projectCount: 12,
    profileViews: 1405,
    hireRequests: [
      { id: 'hr_1', requesterName: 'Vogue India', projectType: 'Editorial Shoot', status: 'IN_DISCUSSION', dateNeeded: new Date().toISOString() }
    ],
    castingApplications: [
      { id: 'app_1', castingCall: { title: 'Summer Campaign Lead' }, status: 'SHORTLISTED' }
    ]
  };

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          <Reveal direction="up">
            <div className="mb-12 border-b border-[var(--color-border)] pb-8 flex flex-col md:flex-row justify-between items-start md:items-end">
              <div>
                <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-2 block">
                  Talent Portal
                </span>
                <h1 className="text-4xl font-serif text-[var(--color-text-main)]">
                  My Dashboard
                </h1>
              </div>
              <div className="flex gap-4 mt-6 md:mt-0">
                <a href={`/talent/${mockProfile.slug}`} target="_blank" className="px-6 py-2 border border-[var(--color-border)] hover:border-[var(--color-text-main)] transition-colors uppercase tracking-widest text-xs font-semibold">
                  View Public Profile
                </a>
                <button className="px-6 py-2 bg-[var(--color-primary)] text-black uppercase tracking-widest text-xs font-semibold hover:bg-white transition-colors">
                  Edit Profile
                </button>
              </div>
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.1}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <div className="border border-[var(--color-border)] bg-[var(--color-surface)] p-6">
                <span className="text-xs uppercase tracking-widest text-[var(--color-text-muted)] block mb-2">Profile Status</span>
                <span className={`text-xl font-serif ${mockProfile.status === 'ACTIVE' ? 'text-[var(--color-primary)]' : 'text-yellow-500'}`}>
                  {mockProfile.status.replace('_', ' ')}
                </span>
              </div>
              <div className="border border-[var(--color-border)] bg-[var(--color-surface)] p-6">
                <span className="text-xs uppercase tracking-widest text-[var(--color-text-muted)] block mb-2">Profile Views</span>
                <span className="text-xl font-serif text-[var(--color-text-main)]">{mockProfile.profileViews}</span>
              </div>
              <div className="border border-[var(--color-border)] bg-[var(--color-surface)] p-6">
                <span className="text-xs uppercase tracking-widest text-[var(--color-text-muted)] block mb-2">Completed Projects</span>
                <span className="text-xl font-serif text-[var(--color-text-main)]">{mockProfile.projectCount}</span>
              </div>
            </div>
          </Reveal>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Reveal direction="up" delay={0.2}>
              <section>
                <h2 className="text-xl font-serif text-[var(--color-text-main)] mb-6">Inbound Direct Requests</h2>
                <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6">
                  {mockProfile.hireRequests.length > 0 ? (
                    <ul className="space-y-6">
                      {mockProfile.hireRequests.map((hr: any) => (
                        <li key={hr.id} className="border-b border-[var(--color-border)] pb-6 last:border-0 last:pb-0">
                          <div className="flex justify-between items-start mb-2">
                            <h3 className="font-semibold text-[var(--color-text-main)]">{hr.requesterName}</h3>
                            <span className="px-2 py-1 border border-[var(--color-primary)] text-[var(--color-primary)] text-[10px] uppercase tracking-widest">
                              {hr.status.replace('_', ' ')}
                            </span>
                          </div>
                          <p className="text-sm text-[var(--color-text-muted)] mb-4">{hr.projectType}</p>
                          <div className="flex gap-4">
                            <button className="text-xs tracking-widest uppercase hover:text-[var(--color-primary)] transition-colors">Accept Request</button>
                            <button className="text-xs tracking-widest uppercase hover:text-red-500 transition-colors">Decline</button>
                          </div>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-[var(--color-text-muted)] text-sm italic">No direct hire requests at the moment.</p>
                  )}
                </div>
              </section>
            </Reveal>

            <Reveal direction="up" delay={0.3}>
              <section>
                <h2 className="text-xl font-serif text-[var(--color-text-main)] mb-6">Active Casting Applications</h2>
                <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6">
                  {mockProfile.castingApplications.length > 0 ? (
                    <ul className="space-y-6">
                      {mockProfile.castingApplications.map((app: any) => (
                        <li key={app.id} className="border-b border-[var(--color-border)] pb-6 last:border-0 last:pb-0 flex justify-between items-center">
                          <div>
                            <h3 className="font-semibold text-[var(--color-text-main)]">{app.castingCall.title}</h3>
                          </div>
                          <span className={`text-xs uppercase tracking-widest font-semibold ${
                            app.status === 'SHORTLISTED' ? 'text-[var(--color-primary)]' : 'text-[var(--color-text-muted)]'
                          }`}>
                            {app.status}
                          </span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-[var(--color-text-muted)] text-sm italic mb-4">You haven't applied to any recent castings.</p>
                      <button className="text-xs uppercase tracking-widest font-semibold border-b border-[var(--color-primary)] text-[var(--color-primary)] hover:text-white transition-colors pb-1">
                        Browse Casting Board
                      </button>
                    </div>
                  )}
                </div>
              </section>
            </Reveal>
          </div>

        </div>
      </main>
    </>
  );
}
