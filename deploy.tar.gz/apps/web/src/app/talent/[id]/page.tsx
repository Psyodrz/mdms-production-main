import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';
import Link from 'next/link';

async function getTalentProfile(id: string) {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    const res = await fetch(`${apiUrl}/talent/${id}`, { next: { revalidate: 60 } });
    if (!res.ok) throw new Error('Failed to fetch talent profile');
    
    const json = await res.json();
    return json.data;
  } catch (error) {
    console.error('Error fetching talent profile:', error);
    return null;
  }
}

export default async function TalentProfile({ params }: { params: { id: string } }) {
  const profile = await getTalentProfile(params.id);

  if (!profile) {
    return (
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl text-[var(--color-text-main)] mb-4">Profile Not Found</h1>
          <Link href="/talent" className="text-[var(--color-primary)] hover:underline">
            Return to Directory
          </Link>
        </div>
      </main>
    );
  }

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          {/* Back to Directory */}
          <Reveal direction="up">
            <Link href="/talent" className="inline-flex items-center text-sm text-[var(--color-text-muted)] hover:text-[var(--color-primary)] transition-colors mb-12 uppercase tracking-widest font-semibold">
              &larr; Back to Network
            </Link>
          </Reveal>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
            
            {/* Left Column: Image & Quick Stats */}
            <div className="lg:col-span-5">
              <Reveal direction="up" delay={0.1}>
                {/* Main Image */}
                <div className="aspect-[4/5] bg-[var(--color-surface)] mb-8 relative group overflow-hidden">
                   <div className="w-full h-full bg-[var(--color-overlay)] group-hover:scale-105 transition-transform duration-1000 ease-in-out" />
                </div>
                
                {/* Quick Details */}
                <div className="space-y-6">
                  <div className="border-b border-[var(--color-border)] pb-6">
                    <h3 className="text-sm tracking-widest uppercase text-[var(--color-primary)] mb-2">Location</h3>
                    <p className="text-[var(--color-text-main)] font-light">{profile.city || 'Global'}</p>
                  </div>
                  
                  {profile.engagementRate && (
                    <div className="border-b border-[var(--color-border)] pb-6">
                      <h3 className="text-sm tracking-widest uppercase text-[var(--color-primary)] mb-2">Engagement Rate</h3>
                      <p className="text-[var(--color-text-main)] font-light">{profile.engagementRate}%</p>
                    </div>
                  )}

                  {profile.instagramFollowers && (
                    <div className="border-b border-[var(--color-border)] pb-6">
                      <h3 className="text-sm tracking-widest uppercase text-[var(--color-primary)] mb-2">Reach</h3>
                      <p className="text-[var(--color-text-main)] font-light">{profile.instagramFollowers.toLocaleString()} Followers</p>
                    </div>
                  )}
                </div>
              </Reveal>
            </div>
            
            {/* Right Column: Bio & Booking */}
            <div className="lg:col-span-7">
              <Reveal direction="up" delay={0.2}>
                <div className="mb-12">
                  <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-4 block">
                    {profile.type ? profile.type.replace('_', ' ') : 'Exclusive Talent'}
                  </span>
                  <h1 className="text-5xl md:text-7xl font-serif text-[var(--color-text-main)] mb-8 leading-tight">
                    {profile.user.firstName} {profile.user.lastName}
                  </h1>
                  
                  <div className="text-lg text-[var(--color-text-muted)] font-light leading-relaxed whitespace-pre-wrap max-w-3xl">
                    {profile.bio || 'Represented exclusively by MP Production.'}
                  </div>
                </div>

                {/* Skills/Tags */}
                {profile.skills && profile.skills.length > 0 && (
                  <div className="mb-16">
                    <h3 className="text-sm tracking-widest uppercase text-[var(--color-primary)] mb-6">Expertise</h3>
                    <div className="flex flex-wrap gap-3">
                      {profile.skills.map((skill: string) => (
                        <span key={skill} className="px-5 py-2 border border-[var(--color-border)] text-[var(--color-text-muted)] text-xs tracking-wider uppercase rounded-sm">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Call to Action */}
                <div className="mt-16 p-8 border border-[var(--color-border)] bg-[var(--color-surface)] flex flex-col md:flex-row items-center justify-between gap-6">
                  <div>
                    <h3 className="text-xl font-serif text-[var(--color-text-main)] mb-2">Book {profile.user.firstName}</h3>
                    <p className="text-[var(--color-text-muted)] text-sm font-light">Submit an inquiry to check availability and rates.</p>
                  </div>
                  <Link 
                    href={`/talent/${profile.id}/book`}
                    className="w-full md:w-auto px-8 py-4 bg-[var(--color-primary)] text-[var(--color-base)] uppercase tracking-widest text-sm font-semibold hover:bg-[var(--color-primary-hover)] transition-colors text-center"
                  >
                    Submit Inquiry
                  </Link>
                </div>
              </Reveal>
            </div>

          </div>
        </div>
      </main>

      <footer className="py-12 px-4 border-t border-[var(--color-border)] bg-[var(--color-base)] text-center">
        <p className="text-[var(--color-text-muted)] text-sm">
          &copy; {new Date().getFullYear()} MP Production. All rights reserved.
        </p>
      </footer>
    </>
  );
}
