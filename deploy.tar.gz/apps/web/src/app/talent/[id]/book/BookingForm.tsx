'use client';

import { useState } from 'react';

export function BookingForm({ talentProfileId }: { talentProfileId: string }) {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const formData = new FormData(e.currentTarget);
    const payload = {
      talentProfileId,
      startDate: formData.get('startDate'),
      endDate: formData.get('endDate'),
      location: formData.get('location'),
      details: formData.get('details'),
    };

    try {
      // In a real flow, the JWT token would be included in the headers
      const res = await fetch('http://localhost:3001/api/v1/booking', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // 'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error('Failed to submit booking inquiry');
      }

      setSuccess(true);
    } catch (err: any) {
      setError(err.message || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-green-500/10 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
        </div>
        <h2 className="text-3xl font-serif text-[var(--color-text-main)] mb-4">Inquiry Received</h2>
        <p className="text-[var(--color-text-muted)] font-light mb-8">
          Thank you. Our team will review your project details and get back to you shortly.
        </p>
        <button 
          onClick={() => window.location.href = '/talent'}
          className="px-8 py-4 border border-[var(--color-border)] text-[var(--color-text-main)] text-sm tracking-widest uppercase hover:text-[var(--color-primary)] hover:border-[var(--color-primary)] transition-colors"
        >
          Return to Directory
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {error && (
        <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-500 text-sm">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-2">
          <label className="text-xs tracking-widest uppercase text-[var(--color-text-muted)]">Start Date</label>
          <input 
            type="date" 
            name="startDate" 
            required 
            className="w-full bg-transparent border-b border-[var(--color-border)] py-3 text-[var(--color-text-main)] focus:outline-none focus:border-[var(--color-primary)] transition-colors"
          />
        </div>
        <div className="space-y-2">
          <label className="text-xs tracking-widest uppercase text-[var(--color-text-muted)]">End Date</label>
          <input 
            type="date" 
            name="endDate" 
            required 
            className="w-full bg-transparent border-b border-[var(--color-border)] py-3 text-[var(--color-text-main)] focus:outline-none focus:border-[var(--color-primary)] transition-colors"
          />
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-xs tracking-widest uppercase text-[var(--color-text-muted)]">Location</label>
        <input 
          type="text" 
          name="location" 
          placeholder="E.g., Studio 4, Mumbai or Remote"
          required 
          className="w-full bg-transparent border-b border-[var(--color-border)] py-3 text-[var(--color-text-main)] focus:outline-none focus:border-[var(--color-primary)] transition-colors"
        />
      </div>

      <div className="space-y-2">
        <label className="text-xs tracking-widest uppercase text-[var(--color-text-muted)]">Project Details</label>
        <textarea 
          name="details" 
          rows={5}
          placeholder="Describe your project, usage rights required, and any specific requests..."
          className="w-full bg-transparent border-b border-[var(--color-border)] py-3 text-[var(--color-text-main)] focus:outline-none focus:border-[var(--color-primary)] transition-colors resize-none"
        ></textarea>
      </div>

      <button 
        type="submit" 
        disabled={loading}
        className="w-full py-4 bg-[var(--color-primary)] text-[var(--color-base)] uppercase tracking-widest text-sm font-semibold hover:bg-[var(--color-primary-hover)] transition-colors disabled:opacity-50"
      >
        {loading ? 'Submitting...' : 'Submit Inquiry'}
      </button>
    </form>
  );
}
