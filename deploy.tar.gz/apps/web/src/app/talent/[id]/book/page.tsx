import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';
import Link from 'next/link';
import { BookingForm } from './BookingForm';

async function getTalentProfile(id: string) {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    const res = await fetch(`${apiUrl}/talent/${id}`, { next: { revalidate: 60 } });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data;
  } catch (error) {
    return null;
  }
}

export default async function BookTalentPage({ params }: { params: { id: string } }) {
  const profile = await getTalentProfile(params.id);

  if (!profile) {
    return (
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 flex items-center justify-center">
        <h1 className="text-3xl text-[var(--color-text-main)]">Profile Not Found</h1>
      </main>
    );
  }

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-4xl mx-auto">
          
          <Reveal direction="up">
            <Link href={`/talent/${params.id}`} className="inline-flex items-center text-sm text-[var(--color-text-muted)] hover:text-[var(--color-primary)] transition-colors mb-12 uppercase tracking-widest font-semibold">
              &larr; Back to Profile
            </Link>
          </Reveal>

          <Reveal direction="up" delay={0.1}>
            <div className="mb-12">
              <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-4 block">
                Booking Inquiry
              </span>
              <h1 className="text-4xl md:text-5xl font-serif text-[var(--color-text-main)] mb-4">
                Book {profile.user.firstName} {profile.user.lastName}
              </h1>
              <p className="text-[var(--color-text-muted)] font-light">
                Submit your project details. Our team will review the inquiry and get back to you with availability and a quotation.
              </p>
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.2}>
            <div className="bg-[var(--color-surface)] p-8 md:p-12 border border-[var(--color-border)]">
              <BookingForm talentProfileId={params.id} />
            </div>
          </Reveal>

        </div>
      </main>
    </>
  );
}
