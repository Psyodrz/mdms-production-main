import Link from 'next/link';
import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';

async function getTalentProfiles(searchParams: { [key: string]: string | string[] | undefined }) {
  try {
    const query = new URLSearchParams();
    if (searchParams.search) query.append('search', searchParams.search as string);
    if (searchParams.type) query.append('type', searchParams.type as string);
    
    // In production, this would be an environment variable
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    
    const res = await fetch(`${apiUrl}/talent?${query.toString()}`, { next: { revalidate: 60 } });
    if (!res.ok) throw new Error('Failed to fetch talent');
    
    const json = await res.json();
    return json.data || [];
  } catch (error) {
    console.error('Error fetching talent:', error);
    return []; // Fallback to empty array
  }
}

export default async function TalentDirectory({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  const profiles = await getTalentProfiles(searchParams);

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          <Reveal direction="up">
            {/* Header & Search */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 gap-8">
              <div className="max-w-2xl">
                <span className="text-[var(--color-primary)] tracking-[0.2em] text-sm uppercase font-semibold mb-4 block">
                  The Network
                </span>
                <h1 className="text-5xl md:text-7xl font-serif text-[var(--color-text-main)] mb-6">
                  Exclusive Talent
                </h1>
                <p className="text-lg text-[var(--color-text-muted)] text-balance font-light">
                  Discover elite models, actors, and digital creators curated by MP Production. Our exclusive network represents the highest standard of industry professionals.
                </p>
              </div>
              
              {/* Search Bar */}
              <div className="w-full md:w-96">
                <form className="relative" method="GET" action="/talent">
                  <input 
                    type="text" 
                    name="search"
                    defaultValue={searchParams.search as string || ''}
                    placeholder="Search talent, skills, or location..."
                    className="w-full bg-[var(--color-surface)] border border-[var(--color-border)] text-[var(--color-text-main)] px-6 py-4 rounded-sm focus:outline-none focus:border-[var(--color-primary)] transition-colors placeholder:text-[var(--color-text-muted)]"
                  />
                  <button type="submit" className="absolute right-4 top-1/2 -translate-y-1/2 text-[var(--color-primary)] hover:text-[var(--color-primary-hover)] transition-colors">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="11" cy="11" r="8"></circle>
                      <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                  </button>
                </form>
              </div>
            </div>
          </Reveal>

          {/* Talent Grid */}
          {profiles.length === 0 ? (
            <div className="text-center py-24 text-[var(--color-text-muted)]">
              No talent profiles found matching your search.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {profiles.map((profile: any, index: number) => (
                <Reveal key={profile.id} direction="up" delay={index * 0.1}>
                  <Link href={`/talent/${profile.id}`} className="group cursor-pointer block">
                    {/* Image Container */}
                    <div className="relative aspect-[3/4] overflow-hidden bg-[var(--color-surface)] mb-4 rounded-sm">
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent z-10 opacity-60 group-hover:opacity-80 transition-opacity duration-300" />
                      
                      {/* Placeholder Image */}
                      <div className="w-full h-full bg-[var(--color-overlay)] group-hover:scale-105 transition-transform duration-700 ease-in-out" />
                      
                      {/* Talent Info (Overlaid) */}
                      <div className="absolute bottom-0 left-0 w-full p-6 z-20 translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                        <h3 className="text-xl font-serif text-[var(--color-text-inv)] mb-1">
                          {profile.user.firstName} {profile.user.lastName}
                        </h3>
                        <div className="flex items-center gap-2 text-sm text-[var(--color-primary)] font-medium">
                          <span>{profile.type ? profile.type.replace('_', ' ') : 'TALENT'}</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                </Reveal>
              ))}
            </div>
          )}

          {/* Load More */}
          {profiles.length > 0 && (
            <div className="mt-16 text-center">
              <button className="px-8 py-4 border border-[var(--color-border)] text-[var(--color-text-main)] font-medium tracking-widest uppercase text-sm hover:border-[var(--color-primary)] hover:text-[var(--color-primary)] transition-all duration-300 rounded-sm">
                Load More
              </button>
            </div>
          )}
        </div>
      </main>

      <footer className="py-12 px-4 border-t border-[var(--color-border)] bg-[var(--color-base)] text-center">
        <p className="text-[var(--color-text-muted)] text-sm">
          &copy; {new Date().getFullYear()} MP Production. All rights reserved.
        </p>
      </footer>
    </>
  );
}
