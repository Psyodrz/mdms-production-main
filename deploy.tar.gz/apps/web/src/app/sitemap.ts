import { MetadataRoute } from 'next';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://mpproduction.com';
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';

  const sitemapData: MetadataRoute.Sitemap = [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: 'weekly',
      priority: 1,
    },
    {
      url: `${baseUrl}/portfolio`,
      lastModified: new Date(),
      changeFrequency: 'weekly',
      priority: 0.9,
    },
    {
      url: `${baseUrl}/talent`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.9,
    },
  ];

  // Dynamically add portfolio slugs
  try {
    const pRes = await fetch(`${apiUrl}/cms/portfolio`, { next: { revalidate: 3600 } });
    if (pRes.ok) {
      const { data } = await pRes.json();
      data.forEach((item: any) => {
        sitemapData.push({
          url: `${baseUrl}/portfolio/${item.slug}`,
          lastModified: new Date(item.updatedAt || item.createdAt),
          changeFrequency: 'monthly',
          priority: 0.8,
        });
      });
    }
  } catch (e) {}

  // Dynamically add talent IDs
  try {
    const tRes = await fetch(`${apiUrl}/talent`, { next: { revalidate: 3600 } });
    if (tRes.ok) {
      const { data } = await tRes.json();
      data.forEach((talent: any) => {
        sitemapData.push({
          url: `${baseUrl}/talent/${talent.id}`,
          lastModified: new Date(talent.updatedAt || talent.createdAt),
          changeFrequency: 'weekly',
          priority: 0.7,
        });
      });
    }
  } catch (e) {}

  return sitemapData;
}
