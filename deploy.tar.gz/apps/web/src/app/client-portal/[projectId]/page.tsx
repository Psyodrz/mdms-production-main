import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';
import { notFound } from 'next/navigation';

async function getClientProjectDetails(projectId: string) {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    const res = await fetch(`${apiUrl}/client/projects/${projectId}`, { next: { revalidate: 0 } });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data;
  } catch (error) {
    return null;
  }
}

export default async function ClientProjectWorkspace({ params }: { params: { projectId: string } }) {
  const project = await getClientProjectDetails(params.projectId);

  if (!project) {
    if (process.env.NODE_ENV !== 'production') {
      return <MockClientWorkspace projectId={params.projectId} />;
    }
    return notFound();
  }

  return <ClientWorkspaceUI project={project} />;
}

function ClientWorkspaceUI({ project }: { project: any }) {
  const latestVersion = project.versions?.[0];

  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          <Reveal direction="up">
            <div className="mb-12 border-b border-[var(--color-border)] pb-8 flex justify-between items-end">
              <div>
                <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-2 block">
                  Project Review
                </span>
                <h1 className="text-4xl font-serif text-[var(--color-text-main)]">
                  {project.name}
                </h1>
              </div>
              <div className="flex gap-4">
                <span className="px-4 py-2 border border-[var(--color-border)] bg-[var(--color-surface)] uppercase tracking-widest text-xs font-semibold">
                  Status: {project.status.replace('_', ' ')}
                </span>
              </div>
            </div>
          </Reveal>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            <div className="lg:col-span-2 space-y-8">
              <Reveal direction="up" delay={0.1}>
                <section>
                  <h2 className="text-xl font-serif text-[var(--color-text-main)] mb-6">Latest Version</h2>
                  <div className="bg-black border border-[var(--color-border)] aspect-video relative flex items-center justify-center">
                    {latestVersion ? (
                      // A simulated Video Player UI that would normally wrap an HTML5 video element
                      <div className="w-full h-full relative group">
                        <video 
                          src={latestVersion.fileUrl} 
                          controls 
                          className="w-full h-full object-contain"
                          poster="https://images.unsplash.com/photo-1572044162444-ad60f128bdea?auto=format&fit=crop&q=80"
                        />
                        <div className="absolute top-4 right-4 bg-black/80 px-3 py-1 text-white text-xs uppercase tracking-widest font-mono">
                          v{latestVersion.versionNumber}
                        </div>
                      </div>
                    ) : (
                      <p className="text-[var(--color-text-muted)] italic">No video versions have been uploaded for review yet.</p>
                    )}
                  </div>
                  
                  {/* Timestamp Comment Input UI */}
                  {latestVersion && (
                    <div className="mt-4 bg-[var(--color-surface)] border border-[var(--color-border)] p-4 flex gap-4">
                      <div className="bg-[var(--color-base)] px-4 py-2 border border-[var(--color-border)] font-mono text-[var(--color-primary)] flex items-center">
                        12.5s
                      </div>
                      <input 
                        type="text" 
                        placeholder="Leave a comment at this exact timestamp..." 
                        className="flex-1 bg-transparent border-b border-[var(--color-border)] text-white focus:outline-none focus:border-[var(--color-primary)] px-2"
                      />
                      <button className="px-6 py-2 bg-[var(--color-primary)] text-black uppercase tracking-widest text-xs font-semibold hover:bg-white transition-colors">
                        Post
                      </button>
                    </div>
                  )}
                </section>
              </Reveal>
            </div>

            <div className="space-y-8">
              <Reveal direction="up" delay={0.2}>
                <section>
                  <h2 className="text-xl font-serif text-[var(--color-text-main)] mb-6">Feedback Log</h2>
                  <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6">
                    {project.comments && project.comments.length > 0 ? (
                      <ul className="space-y-4">
                        {project.comments.map((comment: any) => (
                          <li key={comment.id} className="border-b border-[var(--color-border)] pb-4 last:border-0 last:pb-0">
                            <div className="flex justify-between mb-1">
                              <span className="text-[var(--color-primary)] font-mono text-sm">{comment.timestampSec ? `@ ${comment.timestampSec}s` : 'General'}</span>
                              <span className="text-[var(--color-text-muted)] text-xs">{new Date(comment.createdAt).toLocaleDateString()}</span>
                            </div>
                            <p className="text-sm mt-2">{comment.content}</p>
                            <p className="text-[var(--color-text-muted)] text-xs mt-2 italic">- {comment.author?.firstName || 'Client'}</p>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-[var(--color-text-muted)] text-sm italic">No comments have been posted yet.</p>
                    )}
                  </div>
                </section>
              </Reveal>

              <Reveal direction="up" delay={0.3}>
                <section>
                  <h2 className="text-xl font-serif text-[var(--color-text-main)] mb-6">Deliverables</h2>
                  <div className="bg-[var(--color-surface)] border border-[var(--color-border)] p-6 space-y-4 text-center">
                    {project.status === 'COMPLETED' || project.status === 'DELIVERED' ? (
                      <>
                        <p className="text-[var(--color-text-muted)] text-sm mb-4">Final high-resolution master files are ready for download.</p>
                        <button className="w-full py-3 bg-[var(--color-primary)] text-black uppercase tracking-widest text-xs font-semibold hover:bg-white transition-colors">
                          Download ZIP
                        </button>
                      </>
                    ) : (
                      <p className="text-[var(--color-text-muted)] text-sm italic">
                        Downloads will be unlocked once final payment is processed and the project is marked as delivered.
                      </p>
                    )}
                  </div>
                </section>
              </Reveal>
            </div>

          </div>
        </div>
      </main>
    </>
  );
}

// Fallback for UI Development
function MockClientWorkspace({ projectId }: { projectId: string }) {
  return <ClientWorkspaceUI project={{
    id: projectId,
    name: 'Sample Brand Campaign',
    status: 'REVIEW',
    versions: [
      { id: 'v1', versionNumber: 1, fileUrl: '', fileName: 'Proxy_v1.mp4' }
    ],
    comments: [
      { id: '1', timestampSec: 12.5, content: 'Can we cut to the wide shot here instead?', createdAt: new Date().toISOString(), author: { firstName: 'Aditya' } },
      { id: '2', timestampSec: null, content: 'Overall pacing is great, just the ending feels abrupt.', createdAt: new Date().toISOString(), author: { firstName: 'Aditya' } }
    ]
  }} />;
}
