import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';
import { ProjectTracker } from './ProjectTracker';

async function getClientProjects() {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    
    // NOTE: In production, we'd extract the session token from cookies and pass it in headers
    // For now, we mock the fetch by manually passing a mock token if we had one.
    // Assuming the backend has a GET /client/projects endpoint protected by JWT
    
    const res = await fetch(`${apiUrl}/client/projects`, { 
      // headers: { 'Authorization': `Bearer ...` }
      next: { revalidate: 0 } 
    });
    
    if (!res.ok) return [];
    const json = await res.json();
    return json.data || [];
  } catch (error) {
    return [];
  }
}

export default async function ClientPortal() {
  // const projects = await getClientProjects();
  // Using dummy data for UI testing until auth flows are fully wired on the frontend
  const dummyProjects = [
    {
      id: 'proj_1',
      status: 'PRE_PRODUCTION',
      createdAt: new Date().toISOString(),
      bookings: [
        {
          talentProfile: {
            user: { firstName: 'Aria', lastName: 'V.' }
          }
        }
      ]
    },
    {
      id: 'proj_2',
      status: 'EDITING',
      createdAt: new Date(Date.now() - 864000000).toISOString(),
      bookings: [
        {
          talentProfile: {
            user: { firstName: 'Marcus', lastName: 'T.' }
          }
        }
      ]
    }
  ];

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          <Reveal direction="up">
            <div className="mb-12 flex flex-col md:flex-row justify-between items-start md:items-end border-b border-[var(--color-border)] pb-8">
              <div>
                <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-2 block">
                  Client Portal
                </span>
                <h1 className="text-4xl font-serif text-[var(--color-text-main)]">
                  Dashboard
                </h1>
              </div>
              <div className="mt-4 md:mt-0 flex gap-4 text-sm">
                <button className="text-[var(--color-text-muted)] hover:text-[var(--color-primary)] transition-colors">Settings</button>
                <button className="text-[var(--color-text-muted)] hover:text-red-500 transition-colors">Sign Out</button>
              </div>
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.1}>
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              
              {/* Sidebar Menu */}
              <div className="lg:col-span-1 space-y-2">
                {['Active Projects', 'Invoices & Payments', 'Files & Deliverables', 'Support'].map((item, idx) => (
                  <button 
                    key={item} 
                    className={`w-full text-left px-4 py-3 text-sm tracking-wide transition-colors rounded-sm ${
                      idx === 0 
                      ? 'bg-[var(--color-surface)] border border-[var(--color-border)] text-[var(--color-text-main)]' 
                      : 'text-[var(--color-text-muted)] hover:bg-[var(--color-surface)] hover:text-[var(--color-text-main)]'
                    }`}
                  >
                    {item}
                  </button>
                ))}
              </div>

              {/* Main Content Area */}
              <div className="lg:col-span-3">
                <ProjectTracker projects={dummyProjects} />
              </div>

            </div>
          </Reveal>

        </div>
      </main>
    </>
  );
}
