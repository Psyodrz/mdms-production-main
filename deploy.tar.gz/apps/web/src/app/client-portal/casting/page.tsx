import { Navbar } from '@/components/ui/Navbar';
import { Reveal } from '@/components/ui/Reveal';
import Image from 'next/image';

async function getCastingCalls() {
  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1';
    const res = await fetch(`${apiUrl}/casting`, { next: { revalidate: 60 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data || [];
  } catch (error) {
    return [];
  }
}

export default async function ClientCastingBoard() {
  // Using mock data for UI testing
  const calls = [
    {
      id: 'cast_1',
      title: 'Summer Fashion Campaign',
      projectType: 'Brand Shoot',
      talentTypesNeeded: ['MODEL', 'INFLUENCER'],
      city: 'Mumbai',
      compensationType: 'Paid',
      status: 'PUBLISHED',
      deadline: new Date(Date.now() + 864000000).toISOString(),
      applications: [
        {
          id: 'app_1', status: 'SHORTLISTED', talent: {
            user: { firstName: 'Aria', lastName: 'V.', avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200' }
          }
        },
        {
          id: 'app_2', status: 'APPLIED', talent: {
            user: { firstName: 'Sam', lastName: 'R.', avatarUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=200' }
          }
        }
      ]
    }
  ];

  return (
    <>
      <Navbar />
      
      <main className="min-h-screen bg-[var(--color-base)] pt-32 px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          
          <Reveal direction="up">
            <div className="mb-12 border-b border-[var(--color-border)] pb-8 flex flex-col md:flex-row justify-between items-start md:items-end">
              <div>
                <span className="text-[var(--color-primary)] tracking-[0.2em] text-xs uppercase font-semibold mb-2 block">
                  Client Portal
                </span>
                <h1 className="text-4xl font-serif text-[var(--color-text-main)]">
                  Casting Board
                </h1>
                <p className="text-[var(--color-text-muted)] mt-2">Manage open casting calls and view applicant shortlists.</p>
              </div>
              <div className="mt-6 md:mt-0">
                <button className="px-6 py-3 bg-[var(--color-primary)] text-black uppercase tracking-widest text-xs font-semibold hover:bg-white transition-colors">
                  + Create New Casting Call
                </button>
              </div>
            </div>
          </Reveal>

          <Reveal direction="up" delay={0.1}>
            <div className="space-y-8">
              {calls.map(call => (
                <div key={call.id} className="border border-[var(--color-border)] bg-[var(--color-surface)]">
                  
                  {/* Call Header */}
                  <div className="p-6 border-b border-[var(--color-border)] flex justify-between items-center bg-black/20">
                    <div>
                      <h2 className="text-2xl font-serif text-[var(--color-text-main)]">{call.title}</h2>
                      <p className="text-[var(--color-text-muted)] text-sm mt-1">{call.projectType} • {call.city} • Deadline: {new Date(call.deadline).toLocaleDateString()}</p>
                    </div>
                    <span className="px-4 py-1.5 border border-[var(--color-primary)] text-[var(--color-primary)] text-xs uppercase tracking-widest">
                      {call.status}
                    </span>
                  </div>

                  {/* Applicants Shortlist */}
                  <div className="p-6">
                    <h3 className="text-sm tracking-widest uppercase font-semibold text-[var(--color-text-main)] mb-6">Review Applicants ({call.applications.length})</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {call.applications.map(app => (
                        <div key={app.id} className="border border-[var(--color-border)] flex items-center p-4 gap-4 hover:border-[var(--color-text-main)] transition-colors cursor-pointer group">
                          <div className="w-16 h-16 relative overflow-hidden rounded-full border border-[var(--color-border)]">
                            {app.talent.user.avatarUrl ? (
                              <Image src={app.talent.user.avatarUrl} alt="Avatar" fill className="object-cover" />
                            ) : (
                              <div className="w-full h-full bg-black flex items-center justify-center text-xl font-serif text-[var(--color-text-muted)]">
                                {app.talent.user.firstName[0]}
                              </div>
                            )}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold text-white group-hover:text-[var(--color-primary)] transition-colors">
                              {app.talent.user.firstName} {app.talent.user.lastName}
                            </h4>
                            <span className={`text-[10px] uppercase tracking-widest ${app.status === 'SHORTLISTED' ? 'text-[var(--color-primary)]' : 'text-[var(--color-text-muted)]'}`}>
                              {app.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>

                  </div>
                </div>
              ))}
            </div>
          </Reveal>

        </div>
      </main>
    </>
  );
}
