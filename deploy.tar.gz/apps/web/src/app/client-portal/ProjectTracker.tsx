'use client';

const STATUS_STAGES = [
  'BOOKED',
  'PRE_PRODUCTION',
  'SHOOT',
  'EDITING',
  'REVIEW',
  'REVISION',
  'DELIVERED',
  'COMPLETED'
];

export function ProjectTracker({ projects }: { projects: any[] }) {
  if (projects.length === 0) {
    return (
      <div className="border border-[var(--color-border)] bg-[var(--color-surface)] p-12 text-center">
        <p className="text-[var(--color-text-muted)] font-light">You have no active projects.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {projects.map((project, idx) => {
        const currentStageIdx = STATUS_STAGES.indexOf(project.status);
        const talentNames = project.bookings?.map((b: any) => `${b.talentProfile.user.firstName} ${b.talentProfile.user.lastName}`).join(', ') || 'N/A';

        return (
          <div key={idx} className="border border-[var(--color-border)] bg-[var(--color-surface)] p-6 md:p-8 relative overflow-hidden">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
              <div>
                <h3 className="text-xl font-serif text-[var(--color-text-main)] mb-1">
                  Project: {project.id.slice(0, 8).toUpperCase()}
                </h3>
                <p className="text-[var(--color-text-muted)] text-sm font-light">
                  Talent: {talentNames} | Date: {new Date(project.createdAt).toLocaleDateString()}
                </p>
              </div>
              <span className="px-4 py-1.5 border border-[var(--color-primary)] text-[var(--color-primary)] text-xs uppercase tracking-widest font-semibold bg-black/20">
                {project.status.replace('_', ' ')}
              </span>
            </div>

            {/* Kanban/Tracker Progress Bar */}
            <div className="relative">
              <div className="absolute top-1/2 left-0 w-full h-0.5 bg-[var(--color-border)] -translate-y-1/2 z-0" />
              <div 
                className="absolute top-1/2 left-0 h-0.5 bg-[var(--color-primary)] -translate-y-1/2 z-0 transition-all duration-1000 ease-out" 
                style={{ width: `${(Math.max(currentStageIdx, 0) / (STATUS_STAGES.length - 1)) * 100}%` }}
              />

              <div className="relative z-10 flex justify-between">
                {STATUS_STAGES.map((stage, i) => {
                  const isCompleted = i <= currentStageIdx;
                  const isCurrent = i === currentStageIdx;

                  return (
                    <div key={stage} className="flex flex-col items-center group">
                      <div 
                        className={`w-4 h-4 md:w-5 md:h-5 rounded-full border-2 transition-all duration-500 flex items-center justify-center ${
                          isCompleted 
                            ? 'bg-[var(--color-primary)] border-[var(--color-primary)] shadow-[0_0_10px_var(--color-primary)]' 
                            : 'bg-[var(--color-base)] border-[var(--color-border)]'
                        }`}
                      >
                        {isCompleted && (
                          <div className="w-1.5 h-1.5 bg-black rounded-full" />
                        )}
                      </div>
                      
                      {/* Tooltip on hover for small screens, always visible text on large */}
                      <span className={`mt-4 text-[10px] md:text-xs tracking-wider uppercase whitespace-nowrap hidden md:block transition-colors duration-300 ${
                        isCurrent ? 'text-[var(--color-primary)] font-semibold' : 
                        isCompleted ? 'text-[var(--color-text-main)]' : 'text-[var(--color-text-muted)] opacity-50'
                      }`}>
                        {stage.replace('_', ' ')}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Actions */}
            <div className="mt-8 pt-6 border-t border-[var(--color-border)] flex gap-4">
              <a href={`/client-portal/${project.id}`} className="px-6 py-2 bg-[var(--color-primary)] text-black text-xs uppercase tracking-widest font-semibold hover:bg-[var(--color-primary-hover)] transition-colors inline-block text-center">
                {project.status === 'REVIEW' ? 'Review Deliverables' : 'Open Workspace'}
              </a>
              {project.status === 'REVIEW' && (
                <button className="px-6 py-2 border border-[var(--color-border)] text-[var(--color-text-main)] text-xs uppercase tracking-widest font-semibold hover:border-red-500 hover:text-red-500 transition-colors">
                  Request Revision
                </button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
