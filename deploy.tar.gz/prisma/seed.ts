import { PrismaClient, Role } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seed...');

  // 1. Clean existing dev data (optional, handle carefully)
  // await prisma.auditLog.deleteMany();
  // await prisma.payment.deleteMany();
  // await prisma.booking.deleteMany();
  // await prisma.project.deleteMany();
  // await prisma.talentProfile.deleteMany();
  // await prisma.client.deleteMany();
  // await prisma.user.deleteMany();

  const passwordHash = await bcrypt.hash('Admin@123', 12);

  // 2. Create Super Admin
  const superAdmin = await prisma.user.upsert({
    where: { email: 'admin@mpproduction.com' },
    update: {},
    create: {
      email: 'admin@mpproduction.com',
      firstName: 'Super',
      lastName: 'Admin',
      passwordHash,
      role: Role.SUPER_ADMIN,
      isActive: true,
      employee: {
        create: {
          department: 'Management',
          position: 'CEO',
        },
      },
    },
  });
  console.log('✅ Super Admin created:', superAdmin.email);

  // 3. Create Test Client
  const clientUser = await prisma.user.upsert({
    where: { email: 'client@example.com' },
    update: {},
    create: {
      email: 'client@example.com',
      firstName: 'Acme',
      lastName: 'Corp',
      passwordHash, // Just for dev, clients usually use OTP
      role: Role.CLIENT,
      isActive: true,
      client: {
        create: {
          companyName: 'Acme Corporation',
          industry: 'Technology',
        },
      },
    },
  });
  console.log('✅ Test Client created:', clientUser.email);

  // 4. Create Test Talent
  const talentUser = await prisma.user.upsert({
    where: { email: 'talent@example.com' },
    update: {},
    create: {
      email: 'talent@example.com',
      firstName: 'Elena',
      lastName: 'Smith',
      role: Role.TALENT,
      isActive: true,
      talentProfile: {
        create: {
          type: 'MODEL',
          status: 'ACTIVE',
          bio: 'Professional fashion and editorial model with 5 years experience.',
          location: 'Mumbai, India',
          hourlyRate: 5000,
          dailyRate: 40000,
          availability: 'FLEXIBLE',
          skills: ['Runway', 'Editorial', 'Commercial'],
        },
      },
    },
  });
  console.log('✅ Test Talent created:', talentUser.email);

  console.log('🎉 Seed completed successfully!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
